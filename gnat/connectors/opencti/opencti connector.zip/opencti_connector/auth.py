"""
ctm_sak.connectors.opencti.auth
==================================
Authentication manager for the OpenCTI connector.

OpenCTI uses static Bearer token authentication across all its
API surfaces (GraphQL, TAXII 2.1, SSE stream). The token is a
UUID API key generated in the OpenCTI user profile.

Unlike Wazuh (JWT with expiry) or Splunk (session key), OpenCTI
tokens do not expire unless the server is configured to do so, or
the key is explicitly revoked. There is no refresh flow.

The auth manager is intentionally minimal — it handles header
construction and provides a verify() method that executes a
lightweight GraphQL introspection query to confirm connectivity
and credential validity.

Token privilege model
---------------------
OpenCTI uses RBAC with capability-based access control:
  - Roles are assigned to users
  - Roles have capabilities (e.g. KNOWLEDGE_KNUPDATE, SETTINGS_SETACCESSES)
  - API operations are gated by required capabilities

If a mutation requires capabilities not held by the API key's user,
OpenCTI returns a GraphQL FORBIDDEN error (not HTTP 403).

References
----------
- https://docs.opencti.io/latest/deployment/authentication/
- https://docs.opencti.io/latest/reference/api/
"""

import json
import urllib3

from .config import OpenCTIConfig
from .exceptions import OpenCTIAuthError, OpenCTIGraphQLError


# Lightweight introspection query to verify connectivity + auth
_VERIFY_QUERY = """
query VerifyConnectivity {
  me {
    id
    name
    capabilities {
      name
    }
  }
}
"""


class OpenCTIAuthManager:
    """
    Manages OpenCTI Bearer token authentication.

    Since OpenCTI tokens are static (no expiry by default), this class
    focuses on header construction and connectivity verification rather
    than token lifecycle management.

    Parameters
    ----------
    config : OpenCTIConfig
        Validated connector configuration.
    http : urllib3.PoolManager
        Shared connection pool (owned by OpenCTIClient).
    """

    def __init__(self, config: OpenCTIConfig, http: urllib3.PoolManager) -> None:
        self._config = config
        self._http = http
        self._verified: bool = False
        self._user_info: dict | None = None

    # ── Public ─────────────────────────────────────────────────────────────

    def get_headers(self) -> dict[str, str]:
        """
        Return Authorization + Content-Type headers for GraphQL requests.

        Returns
        -------
        dict[str, str]
        """
        return self._config.graphql_headers

    def get_taxii_headers(self) -> dict[str, str]:
        """Return headers for TAXII 2.1 requests."""
        return self._config.taxii_headers

    def get_stream_headers(self) -> dict[str, str]:
        """Return headers for SSE stream requests."""
        return self._config.stream_headers

    def verify(self, force: bool = False) -> dict:
        """
        Verify API key validity by running a ``me`` query.

        Caches the result after the first successful verification.

        Parameters
        ----------
        force : bool
            If True, re-run the verification even if already cached.

        Returns
        -------
        dict
            User info dict with id, name, capabilities.

        Raises
        ------
        OpenCTIAuthError
            If the API key is invalid, expired, or the server is unreachable.
        """
        if self._verified and not force:
            return self._user_info or {}

        body = json.dumps({"query": _VERIFY_QUERY}).encode("utf-8")
        try:
            response = self._http.request(
                "POST",
                self._config.graphql_url,
                body=body,
                headers=self._config.graphql_headers,
                timeout=self._config.timeout,
            )
        except urllib3.exceptions.HTTPError as exc:
            raise OpenCTIAuthError(
                f"Cannot connect to OpenCTI at {self._config.graphql_url}: {exc}"
            ) from exc

        if response.status == 401:
            raise OpenCTIAuthError(
                "OpenCTI API key authentication failed (HTTP 401). "
                "Check api_key in [opencti] config."
            )
        if response.status == 403:
            raise OpenCTIAuthError(
                "OpenCTI rejected the request (HTTP 403). "
                "Check network/IP restrictions on the OpenCTI instance."
            )
        if response.status != 200:
            raise OpenCTIAuthError(
                f"Unexpected response from OpenCTI: HTTP {response.status}"
            )

        try:
            payload = json.loads(response.data.decode("utf-8"))
        except Exception as exc:
            raise OpenCTIAuthError(
                f"Could not parse OpenCTI response: {exc}"
            ) from exc

        # Check for GraphQL-level auth errors
        errors = payload.get("errors", [])
        if errors:
            code = errors[0].get("extensions", {}).get("code", "")
            if code == "UNAUTHENTICATED":
                raise OpenCTIAuthError(
                    "OpenCTI API key is invalid or has been revoked."
                )
            raise OpenCTIGraphQLError(
                "Unexpected GraphQL error during auth verification.",
                errors=errors,
                operation="VerifyConnectivity",
            )

        user_data = payload.get("data", {}).get("me", {})
        self._user_info = user_data
        self._verified = True
        return user_data

    @property
    def is_verified(self) -> bool:
        """True if verify() has succeeded at least once."""
        return self._verified

    def get_user_capabilities(self) -> list[str]:
        """
        Return the list of capability names for the current API key's user.

        Calls verify() if not already cached.

        Returns
        -------
        list[str]
            Capability name strings (e.g. 'KNOWLEDGE_KNUPDATE').
        """
        info = self.verify()
        caps = info.get("capabilities", [])
        return [c.get("name", "") for c in caps if c.get("name")]

    def has_capability(self, capability: str) -> bool:
        """
        Check whether the current user has a specific capability.

        Parameters
        ----------
        capability : str
            Capability name to check.

        Returns
        -------
        bool
        """
        return capability in self.get_user_capabilities()
