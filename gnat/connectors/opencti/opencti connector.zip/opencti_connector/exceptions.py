"""
ctm_sak.connectors.opencti.exceptions
========================================
Exception hierarchy for the OpenCTI connector.

GraphQL error response shape
-----------------------------
GraphQL errors are returned in the response body even when the HTTP
status is 200. The shape is:

  {
    "data": null,
    "errors": [
      {
        "message": "Access denied",
        "locations": [{"line": 2, "column": 3}],
        "path": ["indicatorAdd"],
        "extensions": {
          "code": "FORBIDDEN",
          "http": {"status": 403}
        }
      }
    ]
  }

Partial success is possible: ``data`` may contain partial results
while ``errors`` lists what failed.

Error extension codes of note:
  FORBIDDEN       — insufficient capability/role
  UNAUTHENTICATED — bad or missing API key
  BAD_USER_INPUT  — validation error on mutation inputs
  NOT_FOUND       — requested object does not exist

HTTP-level errors (before JSON body is available):
  401 — bad API key at the HTTP level
  403 — IP or network restriction

Hierarchy
---------
OpenCTIError
  ├── OpenCTIConfigError
  ├── OpenCTIAuthError              — 401/403 or UNAUTHENTICATED extension code
  ├── OpenCTIGraphQLError           — GraphQL-level errors in response body
  │     ├── OpenCTINotFoundError    — NOT_FOUND extension code
  │     ├── OpenCTIForbiddenError   — FORBIDDEN extension code
  │     └── OpenCTIValidationError  — BAD_USER_INPUT extension code
  ├── OpenCTISTIXError              — STIX mapping failures
  ├── OpenCTITAXIIError             — TAXII 2.1 endpoint errors
  └── OpenCTIStreamError            — SSE stream errors
"""


class OpenCTIError(Exception):
    """Base exception for all OpenCTI connector errors."""


# ── Configuration ─────────────────────────────────────────────────────────────

class OpenCTIConfigError(OpenCTIError):
    """Raised when [opencti] INI section is missing or invalid."""


# ── Authentication ────────────────────────────────────────────────────────────

class OpenCTIAuthError(OpenCTIError):
    """
    Raised when the API key is rejected or missing.
      - HTTP 401 from GraphQL or TAXII endpoints
      - GraphQL error with code UNAUTHENTICATED
    """


# ── GraphQL ───────────────────────────────────────────────────────────────────

class OpenCTIGraphQLError(OpenCTIError):
    """
    Raised when the GraphQL response contains errors.

    Attributes
    ----------
    errors : list[dict]
        Raw GraphQL error objects from the response.
    operation : str
        The GraphQL operation name that produced the error.
    partial_data : dict | None
        Any partial data returned alongside the errors.
    """

    def __init__(
        self,
        message: str,
        errors: list[dict] | None = None,
        operation: str = "",
        partial_data: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.errors = errors or []
        self.operation = operation
        self.partial_data = partial_data

    def __str__(self) -> str:
        parts = [super().__str__()]
        if self.operation:
            parts.append(f"operation={self.operation!r}")
        if self.errors:
            msgs = [e.get("message", "") for e in self.errors[:3]]
            parts.append(f"errors={msgs}")
        return " | ".join(parts)

    @property
    def first_error_code(self) -> str | None:
        """Return the extension code of the first error, if present."""
        if self.errors:
            return (
                self.errors[0]
                .get("extensions", {})
                .get("code")
            )
        return None


class OpenCTINotFoundError(OpenCTIGraphQLError):
    """Raised when a requested object does not exist (NOT_FOUND code)."""


class OpenCTIForbiddenError(OpenCTIGraphQLError):
    """
    Raised when the API key lacks required capability (FORBIDDEN code).
    Check the user's role and capability assignments in OpenCTI.
    """


class OpenCTIValidationError(OpenCTIGraphQLError):
    """Raised on bad mutation inputs (BAD_USER_INPUT code)."""


# ── STIX ─────────────────────────────────────────────────────────────────────

class OpenCTISTIXError(OpenCTIError):
    """
    Raised when STIX 2.1 ↔ OpenCTI object mapping fails.
    Common causes: missing required fields, unsupported object type,
    malformed input.
    """


# ── TAXII ─────────────────────────────────────────────────────────────────────

class OpenCTITAXIIError(OpenCTIError):
    """
    Raised on OpenCTI TAXII 2.1 endpoint errors.
    Only raised when taxii_enabled = true in config.

    Attributes
    ----------
    status_code : int | None
        HTTP status code from the TAXII response.
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code


# ── Stream ────────────────────────────────────────────────────────────────────

class OpenCTIStreamError(OpenCTIError):
    """
    Raised on SSE stream connection or parsing errors.
    Only raised when stream_enabled = true in config.
    """
