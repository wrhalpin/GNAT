"""
ctm_sak.connectors.opencti.reports
=====================================
Report SDO commands for the OpenCTI connector.
Reports are STIX 2.1 report SDOs aggregating related CTI objects.
"""

from typing import Iterator
from .graphql_client import OpenCTIGraphQLClient
from .config import OpenCTIConfig
from .exceptions import OpenCTINotFoundError


_REPORT_FIELDS = """
  id standard_id name description
  report_types published confidence
  created modified
  createdBy { id name }
  labels { edges { node { value color } } }
  externalReferences { edges { node { source_name url } } }
  objects { edges { node { id entity_type ... on BasicObject { id } } } }
"""

_LIST_REPORTS = """
query ListReports($first: Int, $after: String, $filters: FilterGroup) {
  reports(first: $first, after: $after, filters: $filters) {
    pageInfo { hasNextPage endCursor }
    edges { node { """ + _REPORT_FIELDS + """ } }
  }
}
"""

_GET_REPORT = """
query GetReport($id: String!) {
  report(id: $id) { """ + _REPORT_FIELDS + """ }
}
"""

_CREATE_REPORT = """
mutation CreateReport($input: ReportAddInput!) {
  reportAdd(input: $input) { """ + _REPORT_FIELDS + """ }
}
"""


class OpenCTIReportCommands:
    """Report SDO operations."""

    def __init__(self, gql: OpenCTIGraphQLClient, config: OpenCTIConfig) -> None:
        self._gql = gql
        self._config = config

    def list(
        self, first: int | None = None, filters: dict | None = None
    ) -> list[dict]:
        """List reports."""
        vars: dict = {"first": first or self._config.max_results}
        if filters:
            vars["filters"] = filters
        data = self._gql.execute(_LIST_REPORTS, variables=vars)
        return [e["node"] for e in data.get("reports", {}).get("edges", [])]

    def iter_all(self) -> Iterator[dict]:
        """Generator yielding all reports."""
        yield from self._gql.paginate("reports", _LIST_REPORTS)

    def get(self, report_id: str) -> dict:
        """Retrieve a single report by ID."""
        data = self._gql.execute(_GET_REPORT, variables={"id": report_id})
        obj = data.get("report")
        if not obj:
            raise OpenCTINotFoundError(
                f"Report '{report_id}' not found.",
                errors=[], operation="GetReport",
            )
        return obj

    def create(
        self,
        name: str,
        published: str,
        description: str = "",
        report_types: list[str] | None = None,
        confidence: int = 75,
        object_ids: list[str] | None = None,
        labels: list[str] | None = None,
        created_by_id: str | None = None,
    ) -> dict:
        """
        Create a new report SDO.

        Parameters
        ----------
        name : str
            Report title.
        published : str
            ISO 8601 publication date.
        description : str
            Report summary.
        report_types : list[str] | None
            e.g. ['threat-report', 'malware-analysis'].
        confidence : int
            Confidence score 0–100.
        object_ids : list[str] | None
            OpenCTI object IDs to include in the report.
        labels : list[str] | None
            Label value strings.
        created_by_id : str | None
            Creating organisation identity ID.

        Returns
        -------
        dict
            Created report node.
        """
        input_obj: dict = {
            "name": name,
            "published": published,
            "description": description,
            "confidence": confidence,
            "report_types": report_types or ["threat-report"],
        }
        if object_ids:
            input_obj["objects"] = object_ids
        if labels:
            input_obj["objectLabel"] = labels
        if created_by_id:
            input_obj["createdBy"] = created_by_id

        return self._gql.mutate(
            _CREATE_REPORT,
            variables={"input": input_obj},
            result_field="reportAdd",
        )
