"""
ctm_sak.connectors.opencti.relationships
==========================================
STIX 2.1 Relationship (SRO) commands for the OpenCTI connector.

OpenCTI relationships link STIX objects and correspond to STIX 2.1
SROs. They carry a relationship_type and from/to references.

Common relationship types in OpenCTI
--------------------------------------
  indicates        — Indicator → Observable/Threat Actor
  based-on         — Indicator → Observable  (reverse of indicates)
  uses             — Threat Actor → Attack Pattern / Malware / Tool
  targets          — Threat Actor → Identity / Location / Vulnerability
  attributed-to    — Malware/Campaign → Threat Actor
  part-of          — Malware → Malware (family membership)
  related-to       — Generic association
  originates-from  — Threat Actor → Location
  exploits         — Attack Pattern → Vulnerability
  delivers         — Attack Pattern → Malware

References
----------
- https://docs.opencti.io/latest/usage/exploring-analysis/
"""

from typing import Iterator
from .graphql_client import OpenCTIGraphQLClient
from .config import OpenCTIConfig


_REL_FIELDS = """
  id standard_id
  relationship_type
  description confidence
  start_time stop_time
  created modified
  from { id standard_id entity_type ... on BasicObject { id } }
  to   { id standard_id entity_type ... on BasicObject { id } }
  createdBy { id name }
  labels { edges { node { value } } }
"""

_LIST_RELATIONSHIPS = """
query ListRelationships($first: Int, $after: String, $fromId: StixRef, $toId: StixRef, $relationship_type: [String]) {
  stixCoreRelationships(first: $first, after: $after, fromId: $fromId, toId: $toId, relationship_type: $relationship_type) {
    pageInfo { hasNextPage endCursor }
    edges { node { """ + _REL_FIELDS + """ } }
  }
}
"""

_CREATE_RELATIONSHIP = """
mutation CreateRelationship($input: StixCoreRelationshipAddInput!) {
  stixCoreRelationshipAdd(input: $input) { """ + _REL_FIELDS + """ }
}
"""

_DELETE_RELATIONSHIP = """
mutation DeleteRelationship($id: ID!) {
  stixCoreRelationshipEdit(id: $id) { delete }
}
"""


class OpenCTIRelationshipCommands:
    """
    STIX 2.1 Relationship (SRO) operations.

    Parameters
    ----------
    gql : OpenCTIGraphQLClient
    config : OpenCTIConfig
    """

    def __init__(self, gql: OpenCTIGraphQLClient, config: OpenCTIConfig) -> None:
        self._gql = gql
        self._config = config

    def list(
        self,
        from_id: str | None = None,
        to_id: str | None = None,
        relationship_types: list[str] | None = None,
        first: int | None = None,
    ) -> list[dict]:
        """
        List relationships, optionally filtered by from/to IDs or type.

        Parameters
        ----------
        from_id : str | None
            Filter by source object ID.
        to_id : str | None
            Filter by target object ID.
        relationship_types : list[str] | None
            Filter by relationship type(s).
        first : int | None
            Max results.

        Returns
        -------
        list[dict]
            Relationship node dicts.
        """
        vars: dict = {"first": first or self._config.max_results}
        if from_id:
            vars["fromId"] = from_id
        if to_id:
            vars["toId"] = to_id
        if relationship_types:
            vars["relationship_type"] = relationship_types
        data = self._gql.execute(_LIST_RELATIONSHIPS, variables=vars)
        return [
            e["node"]
            for e in data.get("stixCoreRelationships", {}).get("edges", [])
        ]

    def iter_all(
        self,
        from_id: str | None = None,
        to_id: str | None = None,
        relationship_types: list[str] | None = None,
    ) -> Iterator[dict]:
        """Generator yielding all matching relationships."""
        vars: dict = {}
        if from_id:
            vars["fromId"] = from_id
        if to_id:
            vars["toId"] = to_id
        if relationship_types:
            vars["relationship_type"] = relationship_types
        yield from self._gql.paginate(
            "stixCoreRelationships", _LIST_RELATIONSHIPS, vars
        )

    def create(
        self,
        relationship_type: str,
        from_id: str,
        to_id: str,
        description: str = "",
        confidence: int = 75,
        start_time: str | None = None,
        stop_time: str | None = None,
        created_by_id: str | None = None,
    ) -> dict:
        """
        Create a STIX 2.1 relationship between two objects.

        Parameters
        ----------
        relationship_type : str
            Relationship type string (e.g. 'indicates', 'uses', 'targets').
        from_id : str
            Source object OpenCTI ID (the 'from' end).
        to_id : str
            Target object OpenCTI ID (the 'to' end).
        description : str
            Optional relationship description.
        confidence : int
            Confidence score 0–100.
        start_time : str | None
            ISO 8601 relationship start time.
        stop_time : str | None
            ISO 8601 relationship stop time.
        created_by_id : str | None
            Creating identity ID.

        Returns
        -------
        dict
            Created relationship node.
        """
        input_obj: dict = {
            "relationship_type": relationship_type,
            "fromId": from_id,
            "toId": to_id,
            "description": description,
            "confidence": confidence,
        }
        if start_time:
            input_obj["start_time"] = start_time
        if stop_time:
            input_obj["stop_time"] = stop_time
        if created_by_id:
            input_obj["createdBy"] = created_by_id

        return self._gql.mutate(
            _CREATE_RELATIONSHIP,
            variables={"input": input_obj},
            result_field="stixCoreRelationshipAdd",
        )

    def delete(self, relationship_id: str) -> bool:
        """Delete a relationship by ID."""
        self._gql.execute(
            _DELETE_RELATIONSHIP, variables={"id": relationship_id}
        )
        return True

    # ── Convenience helpers ────────────────────────────────────────────────

    def indicator_based_on_observable(
        self,
        indicator_id: str,
        observable_id: str,
        confidence: int = 75,
    ) -> dict:
        """
        Create a 'based-on' relationship: indicator → observable.

        Parameters
        ----------
        indicator_id : str
            OpenCTI indicator ID.
        observable_id : str
            OpenCTI observable ID.
        confidence : int
            Confidence score.

        Returns
        -------
        dict
            Created relationship.
        """
        return self.create(
            "based-on",
            from_id=indicator_id,
            to_id=observable_id,
            confidence=confidence,
        )

    def threat_actor_uses(
        self,
        actor_id: str,
        technique_or_tool_id: str,
        confidence: int = 75,
    ) -> dict:
        """Create a 'uses' relationship: threat actor → attack pattern/tool."""
        return self.create(
            "uses",
            from_id=actor_id,
            to_id=technique_or_tool_id,
            confidence=confidence,
        )
