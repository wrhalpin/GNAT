"""
ctm_sak.connectors.opencti.stream
====================================
SSE (Server-Sent Events) live stream consumer for OpenCTI.

OpenCTI exposes a real-time STIX 2.1 event stream at:
  GET /stream/<stream_id>

Events are delivered as SSE with the format:
  id: <event_id>
  event: <event_type>
  data: <json_payload>

Event types
-----------
  create  — new STIX object created
  update  — existing STIX object updated
  merge   — two objects merged (one becomes alias of the other)
  delete  — object deleted

Data payload shape
------------------
  {
    "data": {<STIX 2.1 object>},
    "context": {
      "patch": [...],        -- for update events: JSON Patch array
      "reverse_patch": [...] -- reverse of patch
    }
  }

Cursor / resumption
-------------------
The ``id`` field on each SSE event is the event cursor. Passing it
as the ``Last-Event-ID`` header on reconnect resumes from that point.

The stream generator caches the last seen cursor so reconnection
can be implemented by the caller.

Note: SSE is a long-lived HTTP connection. OpenCTIStreamCommands
uses a streaming urllib3 request (preload_content=False) and reads
line-by-line. This is the one place in CTM-SAK where we step outside
the standard request/response pattern.

References
----------
- https://docs.opencti.io/latest/deployment/integrations/
- https://html.spec.whatwg.org/multipage/server-sent-events.html
"""

import json
import urllib3

from .config import OpenCTIConfig
from .exceptions import OpenCTIAuthError, OpenCTIStreamError


class OpenCTIStreamCommands:
    """
    OpenCTI SSE live stream consumer.

    Only available when ``stream_enabled = true`` in [opencti] config.

    Parameters
    ----------
    config : OpenCTIConfig
    http : urllib3.PoolManager
    """

    def __init__(self, config: OpenCTIConfig, http: urllib3.PoolManager) -> None:
        self._config = config
        self._http = http
        self._last_event_id: str | None = None

    # ── Stream consumption ─────────────────────────────────────────────────

    def iter_events(
        self,
        from_cursor: str | None = None,
        event_types: list[str] | None = None,
    ):
        """
        Generator that yields parsed SSE events from the OpenCTI stream.

        Each yielded dict contains:
          - ``event_type`` : str  — 'create', 'update', 'merge', 'delete'
          - ``event_id``   : str  — SSE cursor / event ID
          - ``data``       : dict — parsed JSON payload
          - ``stix_object``: dict — the STIX 2.1 object from data.data

        The generator runs indefinitely until the connection is closed
        or an error occurs. Callers should wrap in try/except and use
        ``client.stream.last_event_id`` to resume on reconnect.

        Parameters
        ----------
        from_cursor : str | None
            Resume from this cursor (sent as Last-Event-ID header).
            If None, starts from current stream head.
        event_types : list[str] | None
            Filter to specific event types ('create', 'update', etc.).
            Filtering is done client-side.

        Yields
        ------
        dict
            Parsed SSE event dict.

        Raises
        ------
        OpenCTIAuthError
            If the stream returns HTTP 401.
        OpenCTIStreamError
            On connection failure or parse error.
        """
        headers = dict(self._config.stream_headers)
        cursor = from_cursor or self._last_event_id
        if cursor:
            headers["Last-Event-ID"] = cursor

        try:
            response = self._http.request(
                "GET",
                self._config.stream_url,
                headers=headers,
                timeout=urllib3.Timeout(connect=10.0, read=None),  # no read timeout
                preload_content=False,
            )
        except urllib3.exceptions.HTTPError as exc:
            raise OpenCTIStreamError(
                f"Failed to connect to OpenCTI stream: {exc}"
            ) from exc

        if response.status == 401:
            raise OpenCTIAuthError(
                "Stream authentication failed (HTTP 401). Check api_key."
            )
        if response.status != 200:
            raise OpenCTIStreamError(
                f"Stream returned HTTP {response.status}."
            )

        try:
            yield from self._parse_sse_stream(response, event_types)
        finally:
            response.close()

    def iter_stix_objects(
        self,
        from_cursor: str | None = None,
        event_types: list[str] | None = None,
    ):
        """
        Convenience generator yielding only the STIX 2.1 objects from stream events.

        Parameters
        ----------
        from_cursor : str | None
            Resume cursor.
        event_types : list[str] | None
            Filter by event type.

        Yields
        ------
        tuple[str, dict]
            (event_type, stix_object) pairs.
        """
        for event in self.iter_events(from_cursor=from_cursor, event_types=event_types):
            stix_obj = event.get("stix_object")
            if stix_obj:
                yield event.get("event_type", ""), stix_obj

    @property
    def last_event_id(self) -> str | None:
        """The cursor of the last successfully consumed SSE event."""
        return self._last_event_id

    # ── Internal ───────────────────────────────────────────────────────────

    def _parse_sse_stream(self, response, event_types: list[str] | None):
        """
        Parse SSE lines from a streaming urllib3 response.

        SSE format per event:
          id: <cursor>
          event: <type>
          data: <json>
          (blank line = end of event)
        """
        current_id: str | None = None
        current_event: str | None = None
        current_data: list[str] = []

        try:
            for raw_line in response:
                try:
                    line = raw_line.decode("utf-8").rstrip("\n\r")
                except UnicodeDecodeError:
                    continue

                if not line:
                    # Blank line = dispatch current event
                    if current_data and current_event:
                        data_str = "\n".join(current_data)
                        event = self._dispatch_event(
                            current_id, current_event, data_str, event_types
                        )
                        if event is not None:
                            yield event
                    # Reset for next event
                    current_id = None
                    current_event = None
                    current_data = []

                elif line.startswith("id:"):
                    current_id = line[3:].strip()
                    self._last_event_id = current_id
                elif line.startswith("event:"):
                    current_event = line[6:].strip()
                elif line.startswith("data:"):
                    current_data.append(line[5:].strip())
                # Ignore comment lines (starting with ':')

        except Exception as exc:
            raise OpenCTIStreamError(
                f"Error reading OpenCTI stream: {exc}"
            ) from exc

    def _dispatch_event(
        self,
        event_id: str | None,
        event_type: str,
        data_str: str,
        event_types: list[str] | None,
    ) -> dict | None:
        """Parse and filter a single SSE event."""
        if event_types and event_type not in event_types:
            return None

        try:
            payload = json.loads(data_str)
        except json.JSONDecodeError:
            return None

        stix_obj = payload.get("data")

        return {
            "event_id": event_id,
            "event_type": event_type,
            "data": payload,
            "stix_object": stix_obj,
            "context": payload.get("context", {}),
        }
