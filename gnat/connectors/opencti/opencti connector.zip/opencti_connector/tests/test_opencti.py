"""
tests/connectors/test_opencti.py
===================================
Unit tests for the CTM-SAK OpenCTI connector.

All HTTP is mocked via unittest.mock on urllib3.PoolManager.
No live OpenCTI instance required.

Architecture note
-----------------
OpenCTI uses GraphQL over POST /graphql. All HTTP calls go through
OpenCTIGraphQLClient.execute(). Tests mock urllib3 at the pool level
and verify JSON bodies sent to the GraphQL endpoint.

Coverage
--------
- OpenCTIConfig: validation, INI loading, URL construction
- OpenCTIAuthManager: verify, capability check
- OpenCTIGraphQLClient: execute, error mapping, cursor pagination
- OpenCTIClient: component assembly, disabled surfaces
- OpenCTIIndicatorCommands: list, get, create, helpers
- OpenCTIObservableCommands: list, get, typed creation
- OpenCTIThreatActorCommands: list, get, create
- OpenCTIRelationshipCommands: create, convenience methods
- OpenCTIReportCommands: create, get
- OpenCTITAXIICommands: discovery, collections, objects
- OpenCTIStreamCommands: SSE parsing
- OpenCTISTIXMapper: all four directions

Running
-------
    pytest tests/connectors/test_opencti.py -v
"""

import configparser
import json
import unittest
from unittest.mock import MagicMock, patch, call

from ctm_sak.connectors.opencti.config import OpenCTIConfig, load_opencti_config
from ctm_sak.connectors.opencti.exceptions import (
    OpenCTIAuthError,
    OpenCTIConfigError,
    OpenCTIForbiddenError,
    OpenCTIGraphQLError,
    OpenCTINotFoundError,
    OpenCTISTIXError,
    OpenCTITAXIIError,
    OpenCTIValidationError,
)
from ctm_sak.connectors.opencti.auth import OpenCTIAuthManager
from ctm_sak.connectors.opencti.graphql_client import OpenCTIGraphQLClient
from ctm_sak.connectors.opencti.client import OpenCTIClient
from ctm_sak.connectors.opencti.indicators import OpenCTIIndicatorCommands
from ctm_sak.connectors.opencti.observables import OpenCTIObservableCommands
from ctm_sak.connectors.opencti.threat_actors import OpenCTIThreatActorCommands
from ctm_sak.connectors.opencti.relationships import OpenCTIRelationshipCommands
from ctm_sak.connectors.opencti.reports import OpenCTIReportCommands
from ctm_sak.connectors.opencti.taxii import OpenCTITAXIICommands
from ctm_sak.connectors.opencti.stream import OpenCTIStreamCommands
from ctm_sak.connectors.opencti.stix_mapper import OpenCTISTIXMapper


# ── Fixtures ──────────────────────────────────────────────────────────────────

def _make_config(**overrides) -> OpenCTIConfig:
    defaults = dict(
        url="https://opencti.test.local",
        api_key="test-api-key-uuid",
    )
    defaults.update(overrides)
    return OpenCTIConfig(**defaults)


def _make_response(status: int = 200, body=None) -> MagicMock:
    resp = MagicMock()
    resp.status = status
    payload = body if body is not None else {}
    resp.data = json.dumps(payload).encode("utf-8")
    return resp


def _gql_ok(data: dict) -> dict:
    """Build a GraphQL success response."""
    return {"data": data, "errors": []}


def _gql_error(code: str, message: str) -> dict:
    """Build a GraphQL error response."""
    return {
        "data": None,
        "errors": [{
            "message": message,
            "extensions": {"code": code},
        }]
    }


def _make_gql_client(config=None):
    """Return GraphQL client with mocked HTTP."""
    cfg = config or _make_config()
    mock_http = MagicMock()
    return OpenCTIGraphQLClient(cfg, mock_http), mock_http


def _make_client(config=None) -> tuple[OpenCTIClient, MagicMock]:
    cfg = config or _make_config()
    with patch("ctm_sak.connectors.opencti.client.urllib3.PoolManager") as pm_cls:
        mock_pm = MagicMock()
        pm_cls.return_value = mock_pm
        client = OpenCTIClient(cfg)
        client._http = mock_pm
        client.gql._http = mock_pm
        client.auth._http = mock_pm
    return client, mock_pm


def _paginated_response(field: str, nodes: list, has_next: bool = False, cursor: str = "") -> dict:
    """Build a Relay-paginated GraphQL response."""
    return {field: {
        "pageInfo": {"hasNextPage": has_next, "endCursor": cursor},
        "edges": [{"node": n} for n in nodes],
    }}


# ── Sample data ───────────────────────────────────────────────────────────────

_SAMPLE_INDICATOR = {
    "id": "ind-001",
    "standard_id": "indicator--abc123",
    "name": "Malicious IP",
    "description": "C2 server",
    "pattern": "[ipv4-addr:value = '1.2.3.4']",
    "pattern_type": "stix",
    "valid_from": "2024-01-01T00:00:00.000Z",
    "valid_until": None,
    "confidence": 75,
    "x_opencti_score": 60,
    "x_opencti_main_observable_type": "IPv4-Addr",
    "revoked": False,
    "indicator_types": ["malicious-activity"],
    "created": "2024-01-01T00:00:00.000Z",
    "modified": "2024-01-01T00:00:00.000Z",
    "createdBy": {"id": "org-001", "name": "Threat Intel Team"},
    "labels": {"edges": [{"node": {"id": "lbl-1", "value": "apt", "color": "#ff0000"}}]},
    "externalReferences": {"edges": []},
    "killChainPhases": [{"kill_chain_name": "mitre-attack", "phase_name": "initial-access"}],
}

_SAMPLE_OBSERVABLE = {
    "id": "obs-001",
    "standard_id": "ipv4-addr--def456",
    "entity_type": "IPv4-Addr",
    "observable_value": "1.2.3.4",
    "value": "1.2.3.4",
    "created_at": "2024-01-01T00:00:00.000Z",
    "updated_at": "2024-01-01T00:00:00.000Z",
    "createdBy": None,
    "labels": {"edges": []},
    "externalReferences": {"edges": []},
}


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIConfig
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIConfig(unittest.TestCase):

    def test_minimal_config(self):
        cfg = _make_config()
        self.assertEqual(cfg.url, "https://opencti.test.local")
        self.assertEqual(cfg.api_key, "test-api-key-uuid")

    def test_trailing_slash_stripped(self):
        cfg = OpenCTIConfig(url="https://opencti.test.local/", api_key="key")
        self.assertEqual(cfg.url, "https://opencti.test.local")

    def test_graphql_url(self):
        cfg = _make_config()
        self.assertEqual(cfg.graphql_url, "https://opencti.test.local/graphql")

    def test_taxii_url(self):
        cfg = _make_config()
        self.assertEqual(cfg.taxii_url, "https://opencti.test.local/taxii2")

    def test_stream_url_default(self):
        cfg = _make_config()
        self.assertEqual(cfg.stream_url, "https://opencti.test.local/stream/live")

    def test_stream_url_custom_id(self):
        cfg = _make_config(stream_id="my-stream")
        self.assertEqual(cfg.stream_url, "https://opencti.test.local/stream/my-stream")

    def test_auth_headers(self):
        cfg = _make_config()
        self.assertEqual(
            cfg.auth_headers,
            {"Authorization": "Bearer test-api-key-uuid"}
        )

    def test_graphql_headers(self):
        cfg = _make_config()
        headers = cfg.graphql_headers
        self.assertEqual(headers.get("Content-Type"), "application/json")
        self.assertIn("Authorization", headers)

    def test_taxii_headers(self):
        cfg = _make_config()
        headers = cfg.taxii_headers
        self.assertIn("taxii+json", headers.get("Accept", ""))

    def test_missing_url_raises(self):
        with self.assertRaises(OpenCTIConfigError):
            OpenCTIConfig(url="", api_key="key")

    def test_missing_api_key_raises(self):
        with self.assertRaises(OpenCTIConfigError):
            OpenCTIConfig(url="https://host", api_key="")

    def test_invalid_url_scheme_raises(self):
        with self.assertRaises(OpenCTIConfigError):
            OpenCTIConfig(url="ftp://host", api_key="key")

    def test_load_from_configparser(self):
        parser = configparser.ConfigParser()
        parser.read_dict({
            "opencti": {
                "url": "https://demo.opencti.io",
                "api_key": "my-uuid-key",
                "verify_ssl": "false",
                "max_results": "200",
                "taxii_enabled": "true",
            }
        })
        cfg = load_opencti_config(parser)
        self.assertEqual(cfg.url, "https://demo.opencti.io")
        self.assertEqual(cfg.api_key, "my-uuid-key")
        self.assertFalse(cfg.verify_ssl)
        self.assertEqual(cfg.max_results, 200)
        self.assertTrue(cfg.taxii_enabled)

    def test_load_missing_section_raises(self):
        with self.assertRaises(OpenCTIConfigError):
            load_opencti_config(configparser.ConfigParser())

    def test_load_missing_api_key_raises(self):
        parser = configparser.ConfigParser()
        parser.read_dict({"opencti": {"url": "https://host"}})
        with self.assertRaises(OpenCTIConfigError):
            load_opencti_config(parser)


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIAuthManager
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIAuthManager(unittest.TestCase):

    def _make_auth(self, config=None):
        cfg = config or _make_config()
        mock_http = MagicMock()
        return OpenCTIAuthManager(cfg, mock_http), mock_http

    def test_verify_success(self):
        auth, mock_http = self._make_auth()
        user_data = {"id": "user-1", "name": "Test User", "capabilities": [{"name": "KNOWLEDGE_KNUPDATE"}]}
        mock_http.request.return_value = _make_response(200, _gql_ok({"me": user_data}))
        result = auth.verify()
        self.assertEqual(result["name"], "Test User")

    def test_verify_caches_result(self):
        auth, mock_http = self._make_auth()
        mock_http.request.return_value = _make_response(
            200, _gql_ok({"me": {"id": "u1", "name": "Test", "capabilities": []}})
        )
        auth.verify()
        auth.verify()  # second call
        self.assertEqual(mock_http.request.call_count, 1)

    def test_verify_force_re_runs(self):
        auth, mock_http = self._make_auth()
        mock_http.request.return_value = _make_response(
            200, _gql_ok({"me": {"id": "u1", "capabilities": []}})
        )
        auth.verify()
        auth.verify(force=True)
        self.assertEqual(mock_http.request.call_count, 2)

    def test_verify_401_raises_auth_error(self):
        auth, mock_http = self._make_auth()
        mock_http.request.return_value = _make_response(401)
        with self.assertRaises(OpenCTIAuthError):
            auth.verify()

    def test_verify_unauthenticated_gql_raises(self):
        auth, mock_http = self._make_auth()
        mock_http.request.return_value = _make_response(
            200, _gql_error("UNAUTHENTICATED", "Invalid API key")
        )
        with self.assertRaises(OpenCTIAuthError):
            auth.verify()

    def test_get_user_capabilities(self):
        auth, mock_http = self._make_auth()
        mock_http.request.return_value = _make_response(200, _gql_ok({
            "me": {
                "id": "u1", "name": "Admin",
                "capabilities": [
                    {"name": "KNOWLEDGE_KNUPDATE"},
                    {"name": "SETTINGS_SETACCESSES"},
                ]
            }
        }))
        caps = auth.get_user_capabilities()
        self.assertIn("KNOWLEDGE_KNUPDATE", caps)

    def test_has_capability_true(self):
        auth, mock_http = self._make_auth()
        mock_http.request.return_value = _make_response(200, _gql_ok({
            "me": {"id": "u1", "capabilities": [{"name": "KNOWLEDGE_KNUPDATE"}]}
        }))
        self.assertTrue(auth.has_capability("KNOWLEDGE_KNUPDATE"))

    def test_has_capability_false(self):
        auth, mock_http = self._make_auth()
        mock_http.request.return_value = _make_response(200, _gql_ok({
            "me": {"id": "u1", "capabilities": []}
        }))
        self.assertFalse(auth.has_capability("SETTINGS_SETACCESSES"))


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIGraphQLClient
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIGraphQLClient(unittest.TestCase):

    def test_execute_success(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(
            200, _gql_ok({"me": {"id": "u1"}})
        )
        result = gql.execute("query { me { id } }")
        self.assertEqual(result.get("me", {}).get("id"), "u1")

    def test_execute_sends_post_to_graphql(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(200, {"data": {}})
        gql.execute("query { test }", variables={"x": 1})
        call_args = mock_http.request.call_args
        self.assertEqual(call_args[0][0], "POST")
        body = json.loads(call_args[1]["body"])
        self.assertIn("query", body)
        self.assertEqual(body["variables"]["x"], 1)

    def test_execute_401_raises_auth_error(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(401)
        with self.assertRaises(OpenCTIAuthError):
            gql.execute("query { test }")

    def test_execute_forbidden_gql_raises(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(
            200, _gql_error("FORBIDDEN", "Permission denied")
        )
        with self.assertRaises(OpenCTIForbiddenError):
            gql.execute("mutation { delete }")

    def test_execute_not_found_raises(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(
            200, _gql_error("NOT_FOUND", "Object not found")
        )
        with self.assertRaises(OpenCTINotFoundError):
            gql.execute("query GetObj($id: String!) { indicator(id: $id) { id } }")

    def test_execute_bad_input_raises(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(
            200, _gql_error("BAD_USER_INPUT", "Field 'name' is required")
        )
        with self.assertRaises(OpenCTIValidationError) as ctx:
            gql.execute("mutation { indicatorAdd(input: {}) { id } }")
        self.assertIn("required", str(ctx.exception))

    def test_execute_unknown_gql_error_raises_generic(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(
            200, _gql_error("INTERNAL_SERVER_ERROR", "Something went wrong")
        )
        with self.assertRaises(OpenCTIGraphQLError) as ctx:
            gql.execute("query { test }")
        self.assertNotIsInstance(ctx.exception, (OpenCTIForbiddenError, OpenCTINotFoundError))

    def test_execute_500_retries_then_raises(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(500)
        with patch("time.sleep"):
            with self.assertRaises(OpenCTIGraphQLError):
                gql.execute("query { test }")
        self.assertGreater(mock_http.request.call_count, 1)

    def test_paginate_cursor_iteration(self):
        """paginate() follows hasNextPage and endCursor across two pages."""
        gql, mock_http = _make_gql_client()
        page1 = _paginated_response(
            "indicators",
            [{"id": "ind-1", "name": "A"}, {"id": "ind-2", "name": "B"}],
            has_next=True, cursor="cursor==",
        )
        page2 = _paginated_response(
            "indicators",
            [{"id": "ind-3", "name": "C"}],
            has_next=False,
        )
        mock_http.request.side_effect = [
            _make_response(200, {"data": page1}),
            _make_response(200, {"data": page2}),
        ]
        results = list(gql.paginate("indicators", "query($first:Int,$after:String){indicators(first:$first,after:$after){pageInfo{hasNextPage endCursor}edges{node{id name}}}}"))
        self.assertEqual(len(results), 3)
        self.assertEqual(results[2]["name"], "C")

    def test_paginate_stops_when_no_next_page(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(200, {"data": _paginated_response(
            "indicators", [{"id": "only"}], has_next=False
        )})
        results = list(gql.paginate("indicators", "query($first:Int,$after:String){indicators(first:$first,after:$after){pageInfo{hasNextPage endCursor}edges{node{id}}}}"))
        self.assertEqual(len(results), 1)
        self.assertEqual(mock_http.request.call_count, 1)

    def test_mutate_extracts_result_field(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(200, {"data": {
            "indicatorAdd": {"id": "new-ind", "name": "Test"}
        }})
        result = gql.mutate("mutation($input:IndicatorAddInput!){indicatorAdd(input:$input){id name}}", result_field="indicatorAdd")
        self.assertEqual(result["id"], "new-ind")

    def test_execute_variables_sent_correctly(self):
        gql, mock_http = _make_gql_client()
        mock_http.request.return_value = _make_response(200, {"data": {}})
        gql.execute("query Test($id: String!) { indicator(id: $id) { id } }",
                   variables={"id": "test-id"}, operation_name="Test")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertEqual(body["variables"]["id"], "test-id")
        self.assertEqual(body["operationName"], "Test")


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIClient
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIClient(unittest.TestCase):

    def test_components_assembled(self):
        client, _ = _make_client()
        self.assertIsInstance(client.indicators, OpenCTIIndicatorCommands)
        self.assertIsInstance(client.observables, OpenCTIObservableCommands)
        self.assertIsInstance(client.threat_actors, OpenCTIThreatActorCommands)
        self.assertIsInstance(client.relationships, OpenCTIRelationshipCommands)
        self.assertIsInstance(client.reports, OpenCTIReportCommands)

    def test_taxii_disabled_surface_raises(self):
        cfg = _make_config(taxii_enabled=False)
        client, _ = _make_client(cfg)
        with self.assertRaises(RuntimeError) as ctx:
            _ = client.taxii.list_collections()
        self.assertIn("taxii_enabled", str(ctx.exception))

    def test_taxii_enabled_surface_available(self):
        cfg = _make_config(taxii_enabled=True)
        client, _ = _make_client(cfg)
        self.assertIsInstance(client.taxii, OpenCTITAXIICommands)

    def test_stream_disabled_surface_raises(self):
        cfg = _make_config(stream_enabled=False)
        client, _ = _make_client(cfg)
        with self.assertRaises(RuntimeError):
            _ = client.stream.iter_events()

    def test_context_manager(self):
        cfg = _make_config()
        with patch("ctm_sak.connectors.opencti.client.urllib3.PoolManager"):
            with OpenCTIClient(cfg) as client:
                self.assertIsInstance(client, OpenCTIClient)

    def test_ping_success(self):
        client, mock_http = _make_client()
        mock_http.request.return_value = _make_response(200, _gql_ok({
            "me": {"id": "u1", "capabilities": []}
        }))
        self.assertTrue(client.ping())

    def test_ping_failure(self):
        client, mock_http = _make_client()
        mock_http.request.return_value = _make_response(401)
        self.assertFalse(client.ping())


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIIndicatorCommands
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIIndicatorCommands(unittest.TestCase):

    def _make_indicators(self):
        client, mock_http = _make_client()
        return client.indicators, mock_http

    def test_list_indicators(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": _paginated_response(
            "indicators", [_SAMPLE_INDICATOR], has_next=False
        )})
        results = ind_cmd.list()
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["name"], "Malicious IP")

    def test_get_indicator_found(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {
            "indicator": _SAMPLE_INDICATOR
        }})
        result = ind_cmd.get("ind-001")
        self.assertEqual(result["id"], "ind-001")

    def test_get_indicator_not_found(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {"indicator": None}})
        with self.assertRaises(OpenCTINotFoundError):
            ind_cmd.get("missing")

    def test_create_indicator(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {
            "indicatorAdd": {**_SAMPLE_INDICATOR, "id": "new-ind"}
        }})
        result = ind_cmd.create(
            name="Test Indicator",
            pattern="[ipv4-addr:value = '10.0.0.1']",
        )
        self.assertEqual(result["id"], "new-ind")
        # Verify the mutation body includes name and pattern
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertIn("indicatorAdd", body["query"])
        self.assertEqual(body["variables"]["input"]["name"], "Test Indicator")

    def test_create_ip_indicator(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {
            "indicatorAdd": {**_SAMPLE_INDICATOR, "pattern": "[ipv4-addr:value = '1.2.3.4']"}
        }})
        result = ind_cmd.create_ip_indicator("1.2.3.4")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertIn("[ipv4-addr:value = '1.2.3.4']", body["variables"]["input"]["pattern"])

    def test_create_ipv6_indicator(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {"indicatorAdd": _SAMPLE_INDICATOR}})
        ind_cmd.create_ip_indicator("::1")
        body = json.loads(mock_http.request.call_args[1]["body"])
        pattern = body["variables"]["input"]["pattern"]
        self.assertIn("ipv6-addr", pattern)

    def test_create_domain_indicator(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {"indicatorAdd": _SAMPLE_INDICATOR}})
        ind_cmd.create_domain_indicator("evil.com")
        body = json.loads(mock_http.request.call_args[1]["body"])
        pattern = body["variables"]["input"]["pattern"]
        self.assertIn("[domain-name:value = 'evil.com']", pattern)

    def test_create_url_indicator(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {"indicatorAdd": _SAMPLE_INDICATOR}})
        ind_cmd.create_url_indicator("https://evil.com/path")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertIn("url:value", body["variables"]["input"]["pattern"])

    def test_create_file_hash_indicator_sha256(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {"indicatorAdd": _SAMPLE_INDICATOR}})
        ind_cmd.create_file_hash_indicator("abc123", hash_type="SHA-256")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertIn("SHA-256", body["variables"]["input"]["pattern"])

    def test_delete_indicator(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": {
            "stixDomainObjectEdit": {"delete": True}
        }})
        result = ind_cmd.delete("ind-001")
        self.assertTrue(result)

    def test_normalise_indicator(self):
        result = OpenCTIIndicatorCommands.normalise_indicator(_SAMPLE_INDICATOR)
        self.assertEqual(result["id"], "ind-001")
        self.assertEqual(result["standard_id"], "indicator--abc123")
        self.assertEqual(result["pattern"], "[ipv4-addr:value = '1.2.3.4']")
        self.assertIn("apt", result["labels"])
        self.assertEqual(result["created_by"], "Threat Intel Team")
        self.assertEqual(result["kill_chain_phases"][0]["phase_name"], "initial-access")

    def test_get_by_pattern_found(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": _paginated_response(
            "indicators", [_SAMPLE_INDICATOR], has_next=False
        )})
        result = ind_cmd.get_by_pattern("[ipv4-addr:value = '1.2.3.4']")
        self.assertIsNotNone(result)

    def test_get_by_pattern_not_found(self):
        ind_cmd, mock_http = self._make_indicators()
        mock_http.request.return_value = _make_response(200, {"data": _paginated_response(
            "indicators", [], has_next=False
        )})
        result = ind_cmd.get_by_pattern("[url:value = 'https://missing.com']")
        self.assertIsNone(result)


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIObservableCommands
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIObservableCommands(unittest.TestCase):

    def _make_obs(self):
        client, mock_http = _make_client()
        return client.observables, mock_http

    def test_list_observables(self):
        obs_cmd, mock_http = self._make_obs()
        mock_http.request.return_value = _make_response(200, {"data": _paginated_response(
            "stixCyberObservables", [_SAMPLE_OBSERVABLE], has_next=False
        )})
        results = obs_cmd.list()
        self.assertEqual(len(results), 1)

    def test_get_observable_found(self):
        obs_cmd, mock_http = self._make_obs()
        mock_http.request.return_value = _make_response(200, {"data": {
            "stixCyberObservable": _SAMPLE_OBSERVABLE
        }})
        result = obs_cmd.get("obs-001")
        self.assertEqual(result["id"], "obs-001")

    def test_get_observable_not_found(self):
        obs_cmd, mock_http = self._make_obs()
        mock_http.request.return_value = _make_response(200, {"data": {"stixCyberObservable": None}})
        with self.assertRaises(OpenCTINotFoundError):
            obs_cmd.get("missing")

    def test_create_ipv4(self):
        obs_cmd, mock_http = self._make_obs()
        mock_http.request.return_value = _make_response(200, {"data": {
            "stixCyberObservableAdd": {**_SAMPLE_OBSERVABLE, "id": "new-obs"}
        }})
        result = obs_cmd.create_ipv4("1.2.3.4")
        self.assertEqual(result["id"], "new-obs")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertIn("IPv4-Addr", body["variables"]["type"])

    def test_create_domain(self):
        obs_cmd, mock_http = self._make_obs()
        mock_http.request.return_value = _make_response(200, {"data": {"stixCyberObservableAdd": _SAMPLE_OBSERVABLE}})
        obs_cmd.create_domain("evil.com")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertEqual(body["variables"]["type"], "Domain-Name")

    def test_create_file_with_hashes(self):
        obs_cmd, mock_http = self._make_obs()
        mock_http.request.return_value = _make_response(200, {"data": {"stixCyberObservableAdd": _SAMPLE_OBSERVABLE}})
        obs_cmd.create_file(
            name="malware.exe",
            md5="abc", sha256="def", size=1024
        )
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertEqual(body["variables"]["type"], "StixFile")
        stix_file = body["variables"]["input"]["StixFile"]
        self.assertEqual(stix_file["name"], "malware.exe")
        self.assertEqual(len(stix_file["hashes"]), 2)

    def test_create_email(self):
        obs_cmd, mock_http = self._make_obs()
        mock_http.request.return_value = _make_response(200, {"data": {"stixCyberObservableAdd": _SAMPLE_OBSERVABLE}})
        obs_cmd.create_email("attacker@evil.com")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertEqual(body["variables"]["type"], "Email-Addr")


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIThreatActorCommands
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIThreatActorCommands(unittest.TestCase):

    def _make_ta(self):
        client, mock_http = _make_client()
        return client.threat_actors, mock_http

    def test_list_threat_actors(self):
        ta_cmd, mock_http = self._make_ta()
        actor = {"id": "ta-1", "standard_id": "threat-actor--x", "name": "APT1", "threat_actor_types": ["nation-state"]}
        mock_http.request.return_value = _make_response(200, {"data": {
            "threatActors": {"edges": [{"node": actor}], "pageInfo": {"hasNextPage": False}}
        }})
        results = ta_cmd.list_threat_actors()
        self.assertEqual(results[0]["name"], "APT1")

    def test_create_threat_actor(self):
        ta_cmd, mock_http = self._make_ta()
        mock_http.request.return_value = _make_response(200, {"data": {
            "threatActorGroupAdd": {"id": "ta-new", "name": "APT99"}
        }})
        result = ta_cmd.create_threat_actor("APT99", description="A sophisticated actor")
        self.assertEqual(result["id"], "ta-new")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertEqual(body["variables"]["input"]["name"], "APT99")

    def test_normalise_threat_actor(self):
        actor = {
            "id": "ta-1", "standard_id": "threat-actor--x", "name": "APT1",
            "description": "Known nation-state actor",
            "threat_actor_types": ["nation-state"],
            "aliases": ["Comment Crew"],
            "sophistication": "expert",
            "resource_level": "government",
            "goals": ["data-exfiltration"],
            "confidence": 90,
            "labels": {"edges": [{"node": {"value": "china"}}]},
        }
        result = OpenCTIThreatActorCommands.normalise_threat_actor(actor)
        self.assertEqual(result["name"], "APT1")
        self.assertIn("china", result["labels"])
        self.assertEqual(result["sophistication"], "expert")


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIRelationshipCommands
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIRelationshipCommands(unittest.TestCase):

    def _make_rel(self):
        client, mock_http = _make_client()
        return client.relationships, mock_http

    def test_create_relationship(self):
        rel_cmd, mock_http = self._make_rel()
        mock_http.request.return_value = _make_response(200, {"data": {
            "stixCoreRelationshipAdd": {
                "id": "rel-1", "relationship_type": "indicates",
                "from": {"id": "ind-1"}, "to": {"id": "obs-1"},
            }
        }})
        result = rel_cmd.create("indicates", "ind-1", "obs-1")
        self.assertEqual(result["relationship_type"], "indicates")
        body = json.loads(mock_http.request.call_args[1]["body"])
        inp = body["variables"]["input"]
        self.assertEqual(inp["relationship_type"], "indicates")
        self.assertEqual(inp["fromId"], "ind-1")
        self.assertEqual(inp["toId"], "obs-1")

    def test_indicator_based_on_observable(self):
        rel_cmd, mock_http = self._make_rel()
        mock_http.request.return_value = _make_response(200, {"data": {
            "stixCoreRelationshipAdd": {"id": "rel-2", "relationship_type": "based-on"}
        }})
        result = rel_cmd.indicator_based_on_observable("ind-1", "obs-1")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertEqual(body["variables"]["input"]["relationship_type"], "based-on")

    def test_delete_relationship(self):
        rel_cmd, mock_http = self._make_rel()
        mock_http.request.return_value = _make_response(200, {"data": {
            "stixCoreRelationshipEdit": {"delete": True}
        }})
        result = rel_cmd.delete("rel-1")
        self.assertTrue(result)


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIReportCommands
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIReportCommands(unittest.TestCase):

    def _make_reports(self):
        client, mock_http = _make_client()
        return client.reports, mock_http

    def test_create_report(self):
        rep_cmd, mock_http = self._make_reports()
        mock_http.request.return_value = _make_response(200, {"data": {
            "reportAdd": {"id": "rep-1", "name": "Threat Report Q1 2024"}
        }})
        result = rep_cmd.create(
            name="Threat Report Q1 2024",
            published="2024-03-01T00:00:00.000Z",
            description="Quarterly threat report",
        )
        self.assertEqual(result["id"], "rep-1")
        body = json.loads(mock_http.request.call_args[1]["body"])
        self.assertEqual(body["variables"]["input"]["name"], "Threat Report Q1 2024")

    def test_get_report_not_found(self):
        rep_cmd, mock_http = self._make_reports()
        mock_http.request.return_value = _make_response(200, {"data": {"report": None}})
        with self.assertRaises(OpenCTINotFoundError):
            rep_cmd.get("missing")


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTITAXIICommands
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTITAXIICommands(unittest.TestCase):

    def _make_taxii(self):
        cfg = _make_config(taxii_enabled=True)
        mock_http = MagicMock()
        return OpenCTITAXIICommands(cfg, mock_http), mock_http

    def test_list_collections(self):
        taxii, mock_http = self._make_taxii()
        mock_http.request.return_value = _make_response(200, {
            "collections": [
                {"id": "col-1", "title": "All Indicators", "can_read": True},
            ]
        })
        collections = taxii.list_collections()
        self.assertEqual(len(collections), 1)
        self.assertEqual(collections[0]["title"], "All Indicators")

    def test_get_objects(self):
        taxii, mock_http = self._make_taxii()
        stix_obj = {"type": "indicator", "id": "indicator--abc", "spec_version": "2.1"}
        mock_http.request.return_value = _make_response(200, {
            "objects": [stix_obj],
            "more": False,
        })
        result = taxii.get_objects("col-1")
        self.assertEqual(len(result["objects"]), 1)
        self.assertEqual(result["objects"][0]["type"], "indicator")

    def test_iter_collection_objects_paginates(self):
        taxii, mock_http = self._make_taxii()
        page1 = {"objects": [{"type": "indicator", "id": "i1"}], "more": True, "next": "cursor1"}
        page2 = {"objects": [{"type": "indicator", "id": "i2"}], "more": False}
        mock_http.request.side_effect = [
            _make_response(200, page1),
            _make_response(200, page2),
        ]
        objects = list(taxii.iter_collection_objects("col-1"))
        self.assertEqual(len(objects), 2)

    def test_401_raises_auth_error(self):
        taxii, mock_http = self._make_taxii()
        mock_http.request.return_value = _make_response(401)
        with self.assertRaises(OpenCTIAuthError):
            taxii.list_collections()

    def test_404_raises_taxii_error(self):
        taxii, mock_http = self._make_taxii()
        mock_http.request.return_value = _make_response(404)
        with self.assertRaises(OpenCTITAXIIError) as ctx:
            taxii.get_collection("missing-col")
        self.assertEqual(ctx.exception.status_code, 404)


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTIStreamCommands (SSE parsing)
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIStreamCommands(unittest.TestCase):

    def _make_stream(self):
        cfg = _make_config(stream_enabled=True)
        mock_http = MagicMock()
        return OpenCTIStreamCommands(cfg, mock_http), mock_http

    def test_iter_events_parses_sse(self):
        stream_cmd, mock_http = self._make_stream()
        stix_obj = {"type": "indicator", "id": "indicator--new"}
        payload = json.dumps({"data": stix_obj})
        sse_lines = [
            b"id: evt-001\n",
            b"event: create\n",
            f"data: {payload}\n".encode(),
            b"\n",  # blank line = end of event
        ]
        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.__iter__ = MagicMock(return_value=iter(sse_lines))
        mock_http.request.return_value = mock_response

        events = list(stream_cmd.iter_events())
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["event_type"], "create")
        self.assertEqual(events[0]["event_id"], "evt-001")
        self.assertEqual(events[0]["stix_object"]["type"], "indicator")

    def test_iter_events_401_raises(self):
        stream_cmd, mock_http = self._make_stream()
        mock_http.request.return_value = _make_response(401)
        mock_http.request.return_value.preload_content = True
        with self.assertRaises(OpenCTIAuthError):
            list(stream_cmd.iter_events())

    def test_event_type_filtering(self):
        stream_cmd, mock_http = self._make_stream()
        stix_obj = {"type": "indicator", "id": "indicator--new"}
        payload = json.dumps({"data": stix_obj})
        sse_lines = [
            b"id: evt-001\n",
            b"event: update\n",
            f"data: {payload}\n".encode(),
            b"\n",
        ]
        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.__iter__ = MagicMock(return_value=iter(sse_lines))
        mock_http.request.return_value = mock_response
        # Only request 'create' events — 'update' should be filtered out
        events = list(stream_cmd.iter_events(event_types=["create"]))
        self.assertEqual(len(events), 0)

    def test_last_event_id_updated(self):
        stream_cmd, mock_http = self._make_stream()
        sse_lines = [
            b"id: cursor-xyz\n",
            b"event: create\n",
            b"data: {\"data\": {\"type\": \"indicator\"}}\n",
            b"\n",
        ]
        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.__iter__ = MagicMock(return_value=iter(sse_lines))
        mock_http.request.return_value = mock_response
        list(stream_cmd.iter_events())
        self.assertEqual(stream_cmd.last_event_id, "cursor-xyz")


# ═════════════════════════════════════════════════════════════════════════════
# OpenCTISTIXMapper
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTISTIXMapper(unittest.TestCase):

    def setUp(self):
        self.mapper = OpenCTISTIXMapper()

    # ── A: OpenCTI → STIX ─────────────────────────────────────────────────

    def test_indicator_to_stix(self):
        obj = self.mapper.indicator_to_stix(_SAMPLE_INDICATOR)
        self.assertEqual(obj["type"], "indicator")
        self.assertEqual(obj["id"], "indicator--abc123")
        self.assertEqual(obj["pattern"], "[ipv4-addr:value = '1.2.3.4']")
        self.assertEqual(obj["confidence"], 75)
        self.assertEqual(len(obj["kill_chain_phases"]), 1)

    def test_indicator_to_stix_generates_id_if_no_standard_id(self):
        node = {**_SAMPLE_INDICATOR, "standard_id": None}
        obj = self.mapper.indicator_to_stix(node)
        self.assertTrue(obj["id"].startswith("indicator--"))

    def test_observable_ipv4_to_stix(self):
        obj = self.mapper.observable_to_stix(_SAMPLE_OBSERVABLE)
        self.assertIsNotNone(obj)
        self.assertEqual(obj["type"], "ipv4-addr")
        self.assertEqual(obj["value"], "1.2.3.4")

    def test_observable_file_with_hashes(self):
        file_obs = {
            "id": "file-1", "standard_id": "file--xyz",
            "entity_type": "StixFile",
            "observable_value": "malware.exe",
            "name": "malware.exe",
            "size": 1024,
            "hashes": [
                {"algorithm": "MD5", "value": "abc"},
                {"algorithm": "SHA-256", "value": "def"},
            ],
        }
        obj = self.mapper.observable_to_stix(file_obs)
        self.assertEqual(obj["type"], "file")
        self.assertEqual(obj["hashes"]["MD5"], "abc")
        self.assertEqual(obj["hashes"]["SHA-256"], "def")
        self.assertEqual(obj["name"], "malware.exe")

    def test_observable_unsupported_type_returns_none(self):
        node = {"entity_type": "UnknownType", "observable_value": "x"}
        result = self.mapper.observable_to_stix(node)
        self.assertIsNone(result)

    def test_threat_actor_to_stix(self):
        actor = {
            "id": "ta-1", "standard_id": "threat-actor--xyz",
            "name": "APT1", "description": "Nation state",
            "threat_actor_types": ["nation-state"],
            "aliases": ["Comment Crew"],
            "goals": ["data-exfiltration"],
            "sophistication": "expert",
            "resource_level": "government",
            "confidence": 90,
            "created": "2024-01-01T00:00:00Z",
            "modified": "2024-01-01T00:00:00Z",
        }
        obj = self.mapper.threat_actor_to_stix(actor)
        self.assertEqual(obj["type"], "threat-actor")
        self.assertEqual(obj["name"], "APT1")
        self.assertIn("Comment Crew", obj["aliases"])

    def test_relationship_to_stix(self):
        rel = {
            "id": "rel-1", "standard_id": "relationship--xyz",
            "relationship_type": "indicates",
            "from": {"id": "ind-1", "standard_id": "indicator--abc"},
            "to": {"id": "obs-1", "standard_id": "ipv4-addr--def"},
            "confidence": 75,
            "description": "",
            "created": "2024-01-01T00:00:00Z",
            "modified": "2024-01-01T00:00:00Z",
        }
        obj = self.mapper.relationship_to_stix(rel)
        self.assertEqual(obj["type"], "relationship")
        self.assertEqual(obj["relationship_type"], "indicates")
        self.assertEqual(obj["source_ref"], "indicator--abc")
        self.assertEqual(obj["target_ref"], "ipv4-addr--def")

    # ── B: STIX → OpenCTI pattern ─────────────────────────────────────────

    def test_sco_to_stix_pattern_ipv4(self):
        sco = {"type": "ipv4-addr", "value": "1.2.3.4"}
        pattern = OpenCTISTIXMapper.sco_to_stix_pattern(sco)
        self.assertEqual(pattern, "[ipv4-addr:value = '1.2.3.4']")

    def test_sco_to_stix_pattern_domain(self):
        sco = {"type": "domain-name", "value": "evil.com"}
        pattern = OpenCTISTIXMapper.sco_to_stix_pattern(sco)
        self.assertEqual(pattern, "[domain-name:value = 'evil.com']")

    def test_sco_to_stix_pattern_file_sha256(self):
        sco = {"type": "file", "hashes": {"SHA-256": "abc123"}}
        pattern = OpenCTISTIXMapper.sco_to_stix_pattern(sco)
        self.assertIn("SHA-256", pattern)
        self.assertIn("abc123", pattern)

    def test_sco_to_stix_pattern_file_no_hashes_returns_none(self):
        sco = {"type": "file", "name": "test.txt"}
        result = OpenCTISTIXMapper.sco_to_stix_pattern(sco)
        self.assertIsNone(result)

    # ── C: Bundle construction ─────────────────────────────────────────────

    def test_to_stix_bundle(self):
        nodes = [_SAMPLE_INDICATOR, _SAMPLE_OBSERVABLE]
        bundle = self.mapper.to_stix_bundle(nodes)
        self.assertEqual(bundle["type"], "bundle")
        self.assertEqual(bundle["spec_version"], "2.1")
        types = {o["type"] for o in bundle["objects"]}
        self.assertIn("indicator", types)
        self.assertIn("ipv4-addr", types)

    def test_to_stix_bundle_deduplication(self):
        nodes = [_SAMPLE_INDICATOR, _SAMPLE_INDICATOR]  # duplicate
        bundle = self.mapper.to_stix_bundle(nodes)
        indicator_objs = [o for o in bundle["objects"] if o["type"] == "indicator"]
        self.assertEqual(len(indicator_objs), 1)

    # ── D: STIX bundle ingestion ───────────────────────────────────────────

    def test_ingest_bundle_routes_types(self):
        indicators_cmd = MagicMock()
        observables_cmd = MagicMock()
        indicators_cmd.get_by_pattern.return_value = None  # skip_existing=True but not found

        bundle = {
            "type": "bundle",
            "spec_version": "2.1",
            "objects": [
                {
                    "type": "indicator",
                    "id": "indicator--1",
                    "name": "Test",
                    "pattern": "[ipv4-addr:value = '1.2.3.4']",
                    "pattern_type": "stix",
                    "valid_from": "2024-01-01T00:00:00Z",
                    "indicator_types": ["malicious-activity"],
                },
                {
                    "type": "ipv4-addr",
                    "id": "ipv4-addr--1",
                    "value": "1.2.3.4",
                },
                {
                    "type": "domain-name",
                    "id": "domain-name--1",
                    "value": "evil.com",
                },
            ]
        }
        summary = self.mapper.ingest_bundle(bundle, indicators_cmd, observables_cmd)
        self.assertEqual(summary["created_indicators"], 1)
        self.assertEqual(summary["created_observables"], 2)
        self.assertEqual(summary["errors"], [])

    def test_ingest_bundle_skip_existing(self):
        indicators_cmd = MagicMock()
        observables_cmd = MagicMock()
        indicators_cmd.get_by_pattern.return_value = {"id": "existing"}  # already exists

        bundle = {
            "type": "bundle", "spec_version": "2.1",
            "objects": [{
                "type": "indicator", "id": "indicator--1",
                "name": "Test", "pattern": "[ipv4-addr:value = '1.2.3.4']",
                "pattern_type": "stix", "valid_from": "2024-01-01T00:00:00Z",
            }]
        }
        summary = self.mapper.ingest_bundle(bundle, indicators_cmd, observables_cmd, skip_existing=True)
        # Indicator already exists → should NOT call create
        indicators_cmd.create.assert_not_called()
        self.assertEqual(summary["created_indicators"], 0)

    def test_ingest_invalid_bundle_raises(self):
        with self.assertRaises(OpenCTISTIXError):
            self.mapper.ingest_bundle(
                {"type": "indicator"},
                MagicMock(), MagicMock()
            )

    def test_ingest_bundle_errors_captured(self):
        indicators_cmd = MagicMock()
        observables_cmd = MagicMock()
        indicators_cmd.get_by_pattern.return_value = None
        indicators_cmd.create.side_effect = Exception("GraphQL error")

        bundle = {
            "type": "bundle", "spec_version": "2.1",
            "objects": [{
                "type": "indicator", "id": "indicator--err",
                "pattern": "[ipv4-addr:value = '2.2.2.2']",
                "pattern_type": "stix", "valid_from": "2024-01-01T00:00:00Z",
            }]
        }
        summary = self.mapper.ingest_bundle(bundle, indicators_cmd, observables_cmd)
        self.assertEqual(len(summary["errors"]), 1)
        self.assertIn("indicator--err", summary["errors"][0]["id"])


# ═════════════════════════════════════════════════════════════════════════════
# Exception hierarchy
# ═════════════════════════════════════════════════════════════════════════════

class TestOpenCTIExceptions(unittest.TestCase):

    def test_all_inherit_from_base(self):
        from ctm_sak.connectors.opencti.exceptions import OpenCTIError
        for exc_cls in [
            OpenCTIConfigError, OpenCTIAuthError, OpenCTIGraphQLError,
            OpenCTINotFoundError, OpenCTIForbiddenError, OpenCTIValidationError,
            OpenCTISTIXError, OpenCTITAXIIError,
        ]:
            self.assertTrue(issubclass(exc_cls, OpenCTIError))

    def test_graphql_error_str_includes_operation(self):
        exc = OpenCTIGraphQLError(
            "test", errors=[{"message": "bad"}], operation="TestQuery"
        )
        s = str(exc)
        self.assertIn("TestQuery", s)
        self.assertIn("bad", s)

    def test_graphql_error_first_code(self):
        exc = OpenCTIGraphQLError(
            "x",
            errors=[{"message": "m", "extensions": {"code": "FORBIDDEN"}}]
        )
        self.assertEqual(exc.first_error_code, "FORBIDDEN")

    def test_not_found_is_graphql_error(self):
        self.assertTrue(issubclass(OpenCTINotFoundError, OpenCTIGraphQLError))

    def test_forbidden_is_graphql_error(self):
        self.assertTrue(issubclass(OpenCTIForbiddenError, OpenCTIGraphQLError))

    def test_taxii_error_has_status_code(self):
        exc = OpenCTITAXIIError("TAXII error", status_code=503)
        self.assertEqual(exc.status_code, 503)


if __name__ == "__main__":
    unittest.main(verbosity=2)
