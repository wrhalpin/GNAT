"""
ctm_sak.connectors.opencti.indicators
========================================
STIX 2.1 Indicator SDO commands for the OpenCTI connector.

OpenCTI indicators correspond directly to STIX 2.1 indicator SDOs.
They carry a STIX pattern (e.g. ``[ipv4-addr:value = '1.2.3.4']``)
and are the primary vehicle for actionable threat intelligence.

Key indicator fields in OpenCTI
---------------------------------
  id                — OpenCTI internal UUID
  standard_id       — STIX 2.1 ID (indicator--<uuid>)
  name              — indicator name / label
  description       — optional description
  pattern           — STIX pattern string
  pattern_type      — 'stix' (default), 'sigma', 'yara', 'suricata'
  valid_from        — ISO 8601 validity start
  valid_until       — ISO 8601 validity end (optional)
  confidence        — integer 0–100
  x_opencti_score   — OpenCTI risk score 0–100
  x_opencti_main_observable_type — hint for main SCO type
  revoked           — bool
  indicator_types   — list of STIX indicator type strings
  created           — ISO 8601 creation timestamp
  modified          — ISO 8601 modification timestamp
  createdBy         — creating organisation identity
  labels            — list of label objects
  externalReferences — list of external reference objects
  killChainPhases   — list of kill chain phase objects

STIX pattern types supported by OpenCTI
-----------------------------------------
  stix      — standard STIX 2.1 pattern syntax
  sigma     — Sigma detection rules
  yara      — YARA malware detection rules
  suricata  — Suricata IDS rules
  tanium    — Tanium signal
  spl       — Splunk SPL

References
----------
- https://docs.opencti.io/latest/reference/api/
- https://stix2.readthedocs.io/en/latest/api/stix2.v21.sdo.html#stix2.v21.sdo.Indicator
"""

from typing import Iterator

from .graphql_client import OpenCTIGraphQLClient
from .config import OpenCTIConfig
from .exceptions import OpenCTINotFoundError


# ── GraphQL fragments ────────────────────────────────────────────────────────

_INDICATOR_FIELDS = """
  id
  standard_id
  name
  description
  pattern
  pattern_type
  valid_from
  valid_until
  confidence
  x_opencti_score
  x_opencti_main_observable_type
  revoked
  indicator_types
  created
  modified
  createdBy { id name }
  labels { edges { node { id value color } } }
  externalReferences { edges { node { id source_name url description } } }
  killChainPhases { id kill_chain_name phase_name }
"""

_LIST_INDICATORS = """
query ListIndicators($first: Int, $after: String, $filters: FilterGroup, $orderBy: IndicatorsOrdering, $orderMode: OrderingMode) {
  indicators(first: $first, after: $after, filters: $filters, orderBy: $orderBy, orderMode: $orderMode) {
    pageInfo { hasNextPage endCursor }
    edges { node { """ + _INDICATOR_FIELDS + """ } }
  }
}
"""

_GET_INDICATOR = """
query GetIndicator($id: String!) {
  indicator(id: $id) { """ + _INDICATOR_FIELDS + """ }
}
"""

_CREATE_INDICATOR = """
mutation CreateIndicator($input: IndicatorAddInput!) {
  indicatorAdd(input: $input) { """ + _INDICATOR_FIELDS + """ }
}
"""

_UPDATE_INDICATOR = """
mutation UpdateIndicator($id: ID!, $input: [EditInput]!) {
  stixDomainObjectEdit(id: $id) {
    fieldPatch(input: $input) { ... on Indicator { """ + _INDICATOR_FIELDS + """ } }
  }
}
"""

_DELETE_INDICATOR = """
mutation DeleteIndicator($id: ID!) {
  stixDomainObjectEdit(id: $id) {
    delete
  }
}
"""

_SEARCH_INDICATORS = """
query SearchIndicators($first: Int, $after: String, $search: String) {
  indicators(first: $first, after: $after, search: $search) {
    pageInfo { hasNextPage endCursor }
    edges { node { """ + _INDICATOR_FIELDS + """ } }
  }
}
"""


class OpenCTIIndicatorCommands:
    """
    STIX 2.1 Indicator SDO operations.

    Parameters
    ----------
    gql : OpenCTIGraphQLClient
        GraphQL engine.
    config : OpenCTIConfig
        Connector configuration.
    """

    def __init__(self, gql: OpenCTIGraphQLClient, config: OpenCTIConfig) -> None:
        self._gql = gql
        self._config = config

    # ── List and search ────────────────────────────────────────────────────

    def list(
        self,
        first: int | None = None,
        filters: dict | None = None,
        order_by: str = "created",
        order_mode: str = "desc",
    ) -> list[dict]:
        """
        List indicators with optional filter and ordering.

        Parameters
        ----------
        first : int | None
            Max indicators to return. Defaults to config.max_results.
        filters : dict | None
            OpenCTI FilterGroup dict for server-side filtering.
            Example: filter by pattern_type:
              {"mode": "and", "filters": [
                {"key": "pattern_type", "values": ["stix"]}
              ], "filterGroups": []}
        order_by : str
            Field to order by: 'created', 'modified', 'valid_from',
            'x_opencti_score', 'confidence', 'name'.
        order_mode : str
            'asc' or 'desc'.

        Returns
        -------
        list[dict]
            Indicator node dicts.
        """
        vars: dict = {
            "first": first or self._config.max_results,
            "orderBy": order_by,
            "orderMode": order_mode,
        }
        if filters:
            vars["filters"] = filters

        data = self._gql.execute(_LIST_INDICATORS, variables=vars)
        return self._extract_nodes(data, "indicators")

    def iter_all(
        self,
        filters: dict | None = None,
        order_by: str = "created",
        order_mode: str = "asc",
    ) -> Iterator[dict]:
        """
        Generator that yields ALL indicators, paginating automatically.

        Parameters
        ----------
        filters : dict | None
            OpenCTI FilterGroup for server-side filtering.
        order_by : str
            Sort field.
        order_mode : str
            Sort direction.

        Yields
        ------
        dict
            Indicator node dicts.
        """
        vars: dict = {"orderBy": order_by, "orderMode": order_mode}
        if filters:
            vars["filters"] = filters
        yield from self._gql.paginate("indicators", _LIST_INDICATORS, vars)

    def search(self, query: str, first: int | None = None) -> list[dict]:
        """
        Full-text search across indicator names and descriptions.

        Parameters
        ----------
        query : str
            Search string.
        first : int | None
            Max results.

        Returns
        -------
        list[dict]
            Matching indicator node dicts.
        """
        vars: dict = {
            "search": query,
            "first": first or self._config.max_results,
        }
        data = self._gql.execute(_SEARCH_INDICATORS, variables=vars)
        return self._extract_nodes(data, "indicators")

    def get(self, indicator_id: str) -> dict:
        """
        Retrieve a single indicator by OpenCTI ID or STIX standard_id.

        Parameters
        ----------
        indicator_id : str
            OpenCTI UUID or STIX indicator-- ID.

        Returns
        -------
        dict
            Indicator node dict.

        Raises
        ------
        OpenCTINotFoundError
            If no indicator with this ID exists.
        """
        data = self._gql.execute(_GET_INDICATOR, variables={"id": indicator_id})
        obj = data.get("indicator")
        if not obj:
            raise OpenCTINotFoundError(
                f"Indicator '{indicator_id}' not found in OpenCTI.",
                errors=[],
                operation="GetIndicator",
            )
        return obj

    def get_by_pattern(self, pattern: str) -> dict | None:
        """
        Find an indicator by its exact STIX pattern string.

        Parameters
        ----------
        pattern : str
            STIX pattern to match, e.g. ``"[ipv4-addr:value = '1.2.3.4']"``.

        Returns
        -------
        dict | None
            Indicator node dict, or None if not found.
        """
        filters = {
            "mode": "and",
            "filters": [{"key": "pattern", "values": [pattern]}],
            "filterGroups": [],
        }
        results = self.list(first=1, filters=filters)
        return results[0] if results else None

    # ── Create / update / delete ───────────────────────────────────────────

    def create(
        self,
        name: str,
        pattern: str,
        pattern_type: str = "stix",
        valid_from: str | None = None,
        valid_until: str | None = None,
        description: str = "",
        confidence: int = 75,
        score: int = 50,
        indicator_types: list[str] | None = None,
        main_observable_type: str | None = None,
        labels: list[str] | None = None,
        external_references: list[dict] | None = None,
        kill_chain_phases: list[dict] | None = None,
        created_by_id: str | None = None,
    ) -> dict:
        """
        Create a new STIX 2.1 indicator in OpenCTI.

        Parameters
        ----------
        name : str
            Indicator name (displayed in UI).
        pattern : str
            STIX/Sigma/YARA/Suricata pattern string.
        pattern_type : str
            'stix', 'sigma', 'yara', 'suricata', 'tanium', or 'spl'.
        valid_from : str | None
            ISO 8601 validity start. Defaults to now.
        valid_until : str | None
            ISO 8601 validity end.
        description : str
            Optional description.
        confidence : int
            Confidence score 0–100.
        score : int
            OpenCTI risk score 0–100 (x_opencti_score).
        indicator_types : list[str] | None
            STIX indicator type strings (e.g. ['malicious-activity']).
        main_observable_type : str | None
            Hint for main observable type (e.g. 'IPv4-Addr', 'Domain-Name').
        labels : list[str] | None
            Label value strings to tag the indicator.
        external_references : list[dict] | None
            External reference dicts with source_name, url, etc.
        kill_chain_phases : list[dict] | None
            List of {kill_chain_name, phase_name} dicts.
        created_by_id : str | None
            OpenCTI Organisation identity ID for attribution.

        Returns
        -------
        dict
            Created indicator node dict.
        """
        from datetime import datetime, timezone
        if valid_from is None:
            valid_from = datetime.now(timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%S.000Z"
            )

        input_obj: dict = {
            "name": name,
            "pattern": pattern,
            "pattern_type": pattern_type,
            "valid_from": valid_from,
            "description": description,
            "confidence": confidence,
            "x_opencti_score": score,
            "indicator_types": indicator_types or ["malicious-activity"],
        }
        if valid_until:
            input_obj["valid_until"] = valid_until
        if main_observable_type:
            input_obj["x_opencti_main_observable_type"] = main_observable_type
        if labels:
            input_obj["objectLabel"] = labels
        if external_references:
            input_obj["externalReferences"] = external_references
        if kill_chain_phases:
            input_obj["killChainPhases"] = kill_chain_phases
        if created_by_id:
            input_obj["createdBy"] = created_by_id

        return self._gql.mutate(
            _CREATE_INDICATOR,
            variables={"input": input_obj},
            result_field="indicatorAdd",
        )

    def update_field(
        self,
        indicator_id: str,
        field: str,
        value,
        operation: str = "replace",
    ) -> dict:
        """
        Update a single field on an existing indicator.

        Parameters
        ----------
        indicator_id : str
            OpenCTI indicator UUID.
        field : str
            Field name to update (e.g. 'confidence', 'x_opencti_score',
            'description', 'valid_until').
        value : any
            New field value.
        operation : str
            'replace', 'add', or 'remove'.

        Returns
        -------
        dict
            Updated indicator node.
        """
        return self._gql.mutate(
            _UPDATE_INDICATOR,
            variables={
                "id": indicator_id,
                "input": [{"key": field, "value": [str(value)], "operation": operation}],
            },
            result_field="stixDomainObjectEdit",
        )

    def delete(self, indicator_id: str) -> bool:
        """
        Delete an indicator from OpenCTI.

        Parameters
        ----------
        indicator_id : str
            OpenCTI indicator UUID.

        Returns
        -------
        bool
            True if successfully deleted.
        """
        self._gql.execute(
            _DELETE_INDICATOR,
            variables={"id": indicator_id},
        )
        return True

    # ── Convenience creation helpers ───────────────────────────────────────

    def create_ip_indicator(
        self,
        ip: str,
        name: str | None = None,
        description: str = "",
        score: int = 50,
        confidence: int = 75,
        valid_from: str | None = None,
        valid_until: str | None = None,
    ) -> dict:
        """
        Create a STIX indicator for a malicious IP address.

        Automatically generates the STIX pattern:
          [ipv4-addr:value = '<ip>']  or  [ipv6-addr:value = '<ip>']

        Parameters
        ----------
        ip : str
            IPv4 or IPv6 address.
        name : str | None
            Indicator name. Defaults to the IP address.
        description : str
            Optional description.
        score : int
            OpenCTI risk score.
        confidence : int
            Confidence level.
        valid_from : str | None
            Validity start.
        valid_until : str | None
            Validity end.

        Returns
        -------
        dict
            Created indicator.
        """
        # Determine IP version
        ip_type = "ipv6-addr" if ":" in ip else "ipv4-addr"
        obs_type = "IPv6-Addr" if ":" in ip else "IPv4-Addr"
        pattern = f"[{ip_type}:value = '{ip}']"
        return self.create(
            name=name or ip,
            pattern=pattern,
            description=description,
            score=score,
            confidence=confidence,
            valid_from=valid_from,
            valid_until=valid_until,
            main_observable_type=obs_type,
            indicator_types=["malicious-activity"],
        )

    def create_domain_indicator(
        self,
        domain: str,
        name: str | None = None,
        description: str = "",
        score: int = 50,
        confidence: int = 75,
        valid_from: str | None = None,
        valid_until: str | None = None,
    ) -> dict:
        """
        Create a STIX indicator for a malicious domain.

        Pattern: [domain-name:value = '<domain>']
        """
        pattern = f"[domain-name:value = '{domain}']"
        return self.create(
            name=name or domain,
            pattern=pattern,
            description=description,
            score=score,
            confidence=confidence,
            valid_from=valid_from,
            valid_until=valid_until,
            main_observable_type="Domain-Name",
            indicator_types=["malicious-activity"],
        )

    def create_url_indicator(
        self,
        url: str,
        name: str | None = None,
        description: str = "",
        score: int = 50,
        confidence: int = 75,
    ) -> dict:
        """
        Create a STIX indicator for a malicious URL.

        Pattern: [url:value = '<url>']
        """
        pattern = f"[url:value = '{url}']"
        return self.create(
            name=name or url[:80],
            pattern=pattern,
            description=description,
            score=score,
            confidence=confidence,
            main_observable_type="Url",
            indicator_types=["malicious-activity"],
        )

    def create_file_hash_indicator(
        self,
        hash_value: str,
        hash_type: str = "SHA-256",
        name: str | None = None,
        description: str = "",
        score: int = 60,
        confidence: int = 80,
    ) -> dict:
        """
        Create a STIX indicator for a malicious file hash.

        Supported hash_type values: 'MD5', 'SHA-1', 'SHA-256', 'SHA-512'.
        Pattern: [file:hashes.'<type>' = '<value>']
        """
        pattern = f"[file:hashes.'{hash_type}' = '{hash_value}']"
        return self.create(
            name=name or f"{hash_type}:{hash_value[:16]}...",
            pattern=pattern,
            description=description,
            score=score,
            confidence=confidence,
            main_observable_type="StixFile",
            indicator_types=["malicious-activity"],
        )

    # ── Normalisation helper ───────────────────────────────────────────────

    @staticmethod
    def normalise_indicator(indicator: dict) -> dict:
        """
        Flatten an OpenCTI indicator node to CTM-SAK normalised format.

        Parameters
        ----------
        indicator : dict
            Raw OpenCTI indicator GraphQL node.

        Returns
        -------
        dict
            Normalised indicator dict aligned with CTM-SAK STIX ORM fields.
        """
        labels = [
            edge.get("node", {}).get("value", "")
            for edge in indicator.get("labels", {}).get("edges", [])
        ]
        ext_refs = [
            edge.get("node", {})
            for edge in indicator.get("externalReferences", {}).get("edges", [])
        ]
        return {
            "id": indicator.get("id"),
            "standard_id": indicator.get("standard_id"),
            "name": indicator.get("name"),
            "description": indicator.get("description"),
            "pattern": indicator.get("pattern"),
            "pattern_type": indicator.get("pattern_type"),
            "valid_from": indicator.get("valid_from"),
            "valid_until": indicator.get("valid_until"),
            "confidence": indicator.get("confidence"),
            "score": indicator.get("x_opencti_score"),
            "revoked": indicator.get("revoked", False),
            "indicator_types": indicator.get("indicator_types", []),
            "main_observable_type": indicator.get("x_opencti_main_observable_type"),
            "created": indicator.get("created"),
            "modified": indicator.get("modified"),
            "created_by": indicator.get("createdBy", {}).get("name"),
            "labels": labels,
            "external_references": ext_refs,
            "kill_chain_phases": indicator.get("killChainPhases", []),
            "_raw": indicator,
        }

    # ── Internal ───────────────────────────────────────────────────────────

    @staticmethod
    def _extract_nodes(data: dict, field: str) -> list[dict]:
        """Extract node list from a paginated GraphQL response."""
        return [
            edge.get("node", {})
            for edge in data.get(field, {}).get("edges", [])
        ]
