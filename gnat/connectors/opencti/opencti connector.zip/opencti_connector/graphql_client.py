"""
ctm_sak.connectors.opencti.graphql_client
==========================================
GraphQL-over-urllib3 engine for the OpenCTI connector.

This is the architectural centrepiece of the OpenCTI connector.
All domain commands (indicators, observables, threat actors, etc.)
delegate their HTTP calls here.

GraphQL over HTTP conventions
------------------------------
- All requests: POST /graphql
- Content-Type: application/json
- Body: {"query": "<gql string>", "variables": {<vars>}}
- Success: HTTP 200, body {"data": {...}, "errors": [...]}
  - errors may be present alongside data (partial success)
  - data may be null if the operation fully failed
- Auth failure: HTTP 401 (pre-GraphQL) or GraphQL UNAUTHENTICATED error
- NOT_FOUND: GraphQL NOT_FOUND extension code (not HTTP 404)

Error handling strategy
------------------------
1. HTTP-level errors (401, 403, 5xx) → raise immediately
2. HTTP 200 with GraphQL errors → inspect extension codes:
     UNAUTHENTICATED → OpenCTIAuthError
     FORBIDDEN       → OpenCTIForbiddenError
     NOT_FOUND       → OpenCTINotFoundError
     BAD_USER_INPUT  → OpenCTIValidationError
     other           → OpenCTIGraphQLError
3. HTTP 200, no errors → return data dict

Pagination model
----------------
OpenCTI uses Relay-style cursor pagination on list queries:
  query {
    indicators(first: 100, after: "cursor==") {
      pageInfo { hasNextPage endCursor }
      edges { node { id ... } }
    }
  }

The paginate() method handles cursor iteration and yields
individual node dicts from the edges array.

Some OpenCTI endpoints also support offset-based pagination
via the ``offset`` argument instead of ``after``.

Usage
-----
    gql = OpenCTIGraphQLClient(config, http)
    data = gql.execute("query { me { id name } }")
    result = gql.execute(INDICATORS_QUERY, variables={"first": 50})
    for node in gql.paginate("indicators", INDICATORS_QUERY, vars):
        process(node)
"""

import json
import time
import urllib3

from .config import OpenCTIConfig
from .exceptions import (
    OpenCTIAuthError,
    OpenCTIForbiddenError,
    OpenCTIGraphQLError,
    OpenCTINotFoundError,
    OpenCTIValidationError,
)


_RETRYABLE_STATUS = {500, 502, 503, 504}
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0
_RETRY_BACKOFF = 2.0

# GraphQL error extension codes
_CODE_UNAUTH = "UNAUTHENTICATED"
_CODE_FORBIDDEN = "FORBIDDEN"
_CODE_NOT_FOUND = "NOT_FOUND"
_CODE_BAD_INPUT = "BAD_USER_INPUT"


class OpenCTIGraphQLClient:
    """
    Lightweight GraphQL-over-urllib3 client for OpenCTI.

    Handles:
      - Request serialisation (query + variables → JSON body)
      - HTTP retry with exponential backoff for transient errors
      - GraphQL error code → CTM-SAK exception mapping
      - Cursor-based pagination via paginate()

    Parameters
    ----------
    config : OpenCTIConfig
        Validated connector configuration.
    http : urllib3.PoolManager
        Shared connection pool.
    """

    def __init__(self, config: OpenCTIConfig, http: urllib3.PoolManager) -> None:
        self._config = config
        self._http = http

    # ── Core execution ─────────────────────────────────────────────────────

    def execute(
        self,
        query: str,
        variables: dict | None = None,
        operation_name: str | None = None,
    ) -> dict:
        """
        Execute a GraphQL query or mutation.

        Parameters
        ----------
        query : str
            GraphQL operation string (query or mutation).
        variables : dict | None
            GraphQL variables dict.
        operation_name : str | None
            Optional operation name for multi-operation documents.

        Returns
        -------
        dict
            The ``data`` field from the GraphQL response.
            May be a partial result if some fields errored.

        Raises
        ------
        OpenCTIAuthError
            On UNAUTHENTICATED error or HTTP 401/403.
        OpenCTIForbiddenError
            On FORBIDDEN error (insufficient capabilities).
        OpenCTINotFoundError
            On NOT_FOUND error.
        OpenCTIValidationError
            On BAD_USER_INPUT error.
        OpenCTIGraphQLError
            On other GraphQL-level errors.
        """
        body: dict = {"query": query}
        if variables:
            body["variables"] = variables
        if operation_name:
            body["operationName"] = operation_name

        encoded = json.dumps(body).encode("utf-8")
        headers = self._config.graphql_headers

        delay = _RETRY_BASE_DELAY
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES + 1):
            try:
                response = self._http.request(
                    "POST",
                    self._config.graphql_url,
                    body=encoded,
                    headers=headers,
                )
            except urllib3.exceptions.HTTPError as exc:
                last_exc = exc
                if attempt < _MAX_RETRIES:
                    time.sleep(delay)
                    delay *= _RETRY_BACKOFF
                    continue
                raise OpenCTIGraphQLError(
                    f"Connection error after {_MAX_RETRIES} retries: {exc}",
                    operation=operation_name or "",
                ) from exc

            # HTTP-level auth failures (before GraphQL parsing)
            if response.status == 401:
                raise OpenCTIAuthError(
                    "OpenCTI rejected API key (HTTP 401). "
                    "Check api_key in [opencti] config."
                )
            if response.status == 403:
                raise OpenCTIAuthError(
                    "OpenCTI access denied (HTTP 403). "
                    "Check network/IP restrictions on the instance."
                )

            # Transient server errors — retry
            if response.status in _RETRYABLE_STATUS and attempt < _MAX_RETRIES:
                time.sleep(delay)
                delay *= _RETRY_BACKOFF
                continue

            if response.status not in (200, 201):
                raise OpenCTIGraphQLError(
                    f"Unexpected HTTP {response.status} from OpenCTI GraphQL.",
                    operation=operation_name or "",
                )

            # ── Parse GraphQL response ─────────────────────────────────
            try:
                payload = json.loads(response.data.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                raise OpenCTIGraphQLError(
                    f"Failed to parse OpenCTI GraphQL response: {exc}",
                    operation=operation_name or "",
                ) from exc

            errors = payload.get("errors", [])
            data = payload.get("data")

            if errors:
                self._raise_from_errors(
                    errors,
                    operation=operation_name or "",
                    partial_data=data,
                )

            return data or {}

        if last_exc:
            raise OpenCTIGraphQLError(
                str(last_exc), operation=operation_name or ""
            ) from last_exc
        raise OpenCTIGraphQLError(
            "GraphQL request failed after retries.",
            operation=operation_name or "",
        )

    # ── Pagination ─────────────────────────────────────────────────────────

    def paginate(
        self,
        field_name: str,
        query: str,
        variables: dict | None = None,
        page_size: int | None = None,
    ):
        """
        Generator that yields all nodes from a paginated GraphQL list field.

        OpenCTI uses Relay cursor pagination:
          - ``first``: page size
          - ``after``: opaque cursor from previous pageInfo.endCursor
          - Response: {edges: [{node: {...}}], pageInfo: {hasNextPage, endCursor}}

        The query must:
          - Accept ``$first: Int`` and ``$after: String`` variables
          - Return ``edges { node { ... } }`` and ``pageInfo { hasNextPage endCursor }``

        Parameters
        ----------
        field_name : str
            Top-level field name in the query response, e.g. ``"indicators"``.
        query : str
            GraphQL query string with ``$first`` and ``$after`` variables.
        variables : dict | None
            Additional query variables (merged with pagination vars).
        page_size : int | None
            Items per page. Defaults to config.max_results.

        Yields
        ------
        dict
            Individual node dicts from the edges array.

        Example
        -------
        QUERY = '''
        query ListIndicators($first: Int, $after: String) {
          indicators(first: $first, after: $after) {
            pageInfo { hasNextPage endCursor }
            edges { node { id name pattern } }
          }
        }
        '''
        for node in gql.paginate("indicators", QUERY):
            print(node["name"])
        """
        first = page_size or self._config.max_results
        cursor: str | None = None
        vars_base = dict(variables or {})

        while True:
            page_vars = {**vars_base, "first": first}
            if cursor:
                page_vars["after"] = cursor

            data = self.execute(query, variables=page_vars)
            field_data = data.get(field_name, {})

            edges = field_data.get("edges", [])
            for edge in edges:
                yield edge.get("node", {})

            page_info = field_data.get("pageInfo", {})
            if not page_info.get("hasNextPage"):
                break

            cursor = page_info.get("endCursor")
            if not cursor:
                break

    def paginate_offset(
        self,
        field_name: str,
        query: str,
        variables: dict | None = None,
        page_size: int | None = None,
    ):
        """
        Generator for offset-based OpenCTI pagination (alternative to cursor).

        Some OpenCTI endpoints accept ``offset`` instead of ``after``.
        The response still returns edges/pageInfo but total is used to
        determine when to stop.

        Parameters
        ----------
        field_name : str
            Top-level response field name.
        query : str
            GraphQL query accepting ``$first: Int`` and ``$offset: Int``.
        variables : dict | None
            Additional query variables.
        page_size : int | None
            Items per page.

        Yields
        ------
        dict
            Individual node dicts.
        """
        first = page_size or self._config.max_results
        offset = 0
        total: int | None = None
        vars_base = dict(variables or {})

        while True:
            page_vars = {**vars_base, "first": first, "offset": offset}
            data = self.execute(query, variables=page_vars)
            field_data = data.get(field_name, {})

            edges = field_data.get("edges", [])
            if total is None:
                total = field_data.get("total", 0)

            for edge in edges:
                yield edge.get("node", {})

            offset += len(edges)
            if not edges or offset >= (total or 0):
                break

    # ── Mutation helper ────────────────────────────────────────────────────

    def mutate(
        self,
        mutation: str,
        variables: dict | None = None,
        result_field: str | None = None,
    ) -> dict:
        """
        Execute a GraphQL mutation and return the result object.

        Parameters
        ----------
        mutation : str
            GraphQL mutation string.
        variables : dict | None
            Mutation input variables.
        result_field : str | None
            Top-level field to extract from data (e.g. 'indicatorAdd').
            If None, returns the full data dict.

        Returns
        -------
        dict
            Mutation result (the created/updated object or operation result).
        """
        data = self.execute(mutation, variables=variables)
        if result_field:
            return data.get(result_field, {})
        return data

    # ── Internal ───────────────────────────────────────────────────────────

    @staticmethod
    def _raise_from_errors(
        errors: list[dict],
        operation: str = "",
        partial_data: dict | None = None,
    ) -> None:
        """
        Map GraphQL error codes to CTM-SAK exception types.

        Raises the most specific applicable exception based on the
        extension code of the first error.
        """
        if not errors:
            return

        first = errors[0]
        code = first.get("extensions", {}).get("code", "")
        message = first.get("message", "OpenCTI GraphQL error")

        kwargs = dict(
            errors=errors,
            operation=operation,
            partial_data=partial_data,
        )

        if code == _CODE_UNAUTH:
            raise OpenCTIAuthError(
                f"OpenCTI authentication error: {message}"
            )
        if code == _CODE_FORBIDDEN:
            raise OpenCTIForbiddenError(
                f"OpenCTI permission denied: {message}", **kwargs
            )
        if code == _CODE_NOT_FOUND:
            raise OpenCTINotFoundError(
                f"OpenCTI resource not found: {message}", **kwargs
            )
        if code == _CODE_BAD_INPUT:
            raise OpenCTIValidationError(
                f"OpenCTI validation error: {message}", **kwargs
            )
        raise OpenCTIGraphQLError(
            f"OpenCTI GraphQL error: {message}", **kwargs
        )
