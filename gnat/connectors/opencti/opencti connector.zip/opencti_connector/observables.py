"""
ctm_sak.connectors.opencti.observables
=========================================
STIX 2.1 Cyber Observable (SCO) commands for the OpenCTI connector.

OpenCTI observables are STIX 2.1 SCOs — the raw observable facts
(IP addresses, domains, file hashes, etc.) that indicators reference.

In OpenCTI, observables are distinct from indicators:
  - Observable: the raw fact ("this IP exists")
  - Indicator: the detection pattern ("[ipv4-addr:value = '...']")
  - Both can be linked via the 'based-on' relationship

Observable types supported by CTM-SAK
--------------------------------------
  IPv4-Addr        → ipv4-addr SCO
  IPv6-Addr        → ipv6-addr SCO
  Domain-Name      → domain-name SCO
  Url              → url SCO
  StixFile         → file SCO (with hashes)
  EmailAddr        → email-addr SCO
  AutonomousSystem → autonomous-system SCO
  NetworkTraffic   → network-traffic SCO
  UserAccount      → user-account SCO
  Process          → process SCO
  WindowsRegistryKey → windows-registry-key SCO
  X509Certificate  → x509-certificate SCO

References
----------
- https://docs.opencti.io/latest/usage/exploring-observables/
"""

from typing import Iterator
from .graphql_client import OpenCTIGraphQLClient
from .config import OpenCTIConfig
from .exceptions import OpenCTINotFoundError


_OBS_FIELDS = """
  id
  standard_id
  entity_type
  observable_value
  created_at
  updated_at
  createdBy { id name }
  labels { edges { node { id value color } } }
  externalReferences { edges { node { id source_name url } } }
  ... on IPv4Addr { value }
  ... on IPv6Addr { value }
  ... on DomainName { value }
  ... on Url { value }
  ... on StixFile {
    name size
    hashes { algorithm value }
  }
  ... on EmailAddr { value }
  ... on AutonomousSystem { number name rir }
  ... on UserAccount { user_id account_login account_type }
"""

_LIST_OBSERVABLES = """
query ListObservables($first: Int, $after: String, $filters: FilterGroup, $types: [String]) {
  stixCyberObservables(first: $first, after: $after, filters: $filters, types: $types) {
    pageInfo { hasNextPage endCursor }
    edges { node { """ + _OBS_FIELDS + """ } }
  }
}
"""

_GET_OBSERVABLE = """
query GetObservable($id: String!) {
  stixCyberObservable(id: $id) { """ + _OBS_FIELDS + """ }
}
"""

_CREATE_OBSERVABLE = """
mutation CreateObservable($type: String!, $input: StixCyberObservableAddInput!) {
  stixCyberObservableAdd(type: $type, input: $input) { """ + _OBS_FIELDS + """ }
}
"""

_DELETE_OBSERVABLE = """
mutation DeleteObservable($id: ID!) {
  stixCyberObservableEdit(id: $id) { delete }
}
"""


class OpenCTIObservableCommands:
    """
    STIX 2.1 Cyber Observable (SCO) operations.

    Parameters
    ----------
    gql : OpenCTIGraphQLClient
    config : OpenCTIConfig
    """

    def __init__(self, gql: OpenCTIGraphQLClient, config: OpenCTIConfig) -> None:
        self._gql = gql
        self._config = config

    def list(
        self,
        first: int | None = None,
        types: list[str] | None = None,
        filters: dict | None = None,
    ) -> list[dict]:
        """
        List cyber observables with optional type and field filters.

        Parameters
        ----------
        first : int | None
            Max results.
        types : list[str] | None
            Filter by observable type(s), e.g. ['IPv4-Addr', 'Domain-Name'].
        filters : dict | None
            OpenCTI FilterGroup for server-side filtering.

        Returns
        -------
        list[dict]
        """
        vars: dict = {"first": first or self._config.max_results}
        if types:
            vars["types"] = types
        if filters:
            vars["filters"] = filters
        data = self._gql.execute(_LIST_OBSERVABLES, variables=vars)
        return [e.get("node", {}) for e in data.get("stixCyberObservables", {}).get("edges", [])]

    def iter_all(self, types: list[str] | None = None) -> Iterator[dict]:
        """Generator yielding all observables of given types."""
        vars: dict = {}
        if types:
            vars["types"] = types
        yield from self._gql.paginate("stixCyberObservables", _LIST_OBSERVABLES, vars)

    def get(self, observable_id: str) -> dict:
        """Retrieve a single observable by ID."""
        data = self._gql.execute(_GET_OBSERVABLE, variables={"id": observable_id})
        obj = data.get("stixCyberObservable")
        if not obj:
            raise OpenCTINotFoundError(
                f"Observable '{observable_id}' not found.",
                errors=[], operation="GetObservable",
            )
        return obj

    def delete(self, observable_id: str) -> bool:
        """Delete an observable by ID."""
        self._gql.execute(_DELETE_OBSERVABLE, variables={"id": observable_id})
        return True

    # ── Typed creation helpers ─────────────────────────────────────────────

    def create_ipv4(
        self,
        value: str,
        description: str = "",
        score: int = 50,
        labels: list[str] | None = None,
    ) -> dict:
        """Create an IPv4-Addr observable."""
        return self._create(
            "IPv4-Addr",
            {"IPv4Addr": {"value": value}},
            description=description, score=score, labels=labels,
        )

    def create_ipv6(self, value: str, description: str = "", score: int = 50) -> dict:
        """Create an IPv6-Addr observable."""
        return self._create("IPv6-Addr", {"IPv6Addr": {"value": value}},
                           description=description, score=score)

    def create_domain(self, value: str, description: str = "", score: int = 50) -> dict:
        """Create a Domain-Name observable."""
        return self._create("Domain-Name", {"DomainName": {"value": value}},
                           description=description, score=score)

    def create_url(self, value: str, description: str = "", score: int = 50) -> dict:
        """Create a URL observable."""
        return self._create("Url", {"Url": {"value": value}},
                           description=description, score=score)

    def create_file(
        self,
        name: str | None = None,
        md5: str | None = None,
        sha1: str | None = None,
        sha256: str | None = None,
        size: int | None = None,
        description: str = "",
        score: int = 50,
    ) -> dict:
        """Create a StixFile observable with optional hashes."""
        hashes = []
        if md5:
            hashes.append({"algorithm": "MD5", "hash": md5})
        if sha1:
            hashes.append({"algorithm": "SHA-1", "hash": sha1})
        if sha256:
            hashes.append({"algorithm": "SHA-256", "hash": sha256})
        file_input: dict = {}
        if name:
            file_input["name"] = name
        if hashes:
            file_input["hashes"] = hashes
        if size is not None:
            file_input["size"] = size
        return self._create("StixFile", {"StixFile": file_input},
                           description=description, score=score)

    def create_email(self, value: str, description: str = "", score: int = 50) -> dict:
        """Create an Email-Addr observable."""
        return self._create("Email-Addr", {"EmailAddr": {"value": value}},
                           description=description, score=score)

    def create_user_account(
        self, user_id: str, account_login: str | None = None,
        account_type: str | None = None, description: str = "",
    ) -> dict:
        """Create a User-Account observable."""
        ua: dict = {"user_id": user_id}
        if account_login:
            ua["account_login"] = account_login
        if account_type:
            ua["account_type"] = account_type
        return self._create("User-Account", {"UserAccount": ua}, description=description)

    # ── Internal ───────────────────────────────────────────────────────────

    def _create(
        self,
        obs_type: str,
        type_specific_input: dict,
        description: str = "",
        score: int = 50,
        labels: list[str] | None = None,
    ) -> dict:
        input_obj: dict = {
            **type_specific_input,
            "x_opencti_description": description,
            "x_opencti_score": score,
        }
        if labels:
            input_obj["objectLabel"] = labels
        return self._gql.mutate(
            _CREATE_OBSERVABLE,
            variables={"type": obs_type, "input": input_obj},
            result_field="stixCyberObservableAdd",
        )
