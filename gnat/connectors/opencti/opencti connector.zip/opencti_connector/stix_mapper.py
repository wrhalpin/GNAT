"""
ctm_sak.connectors.opencti.stix_mapper
=========================================
STIX 2.1 mapping utilities for the OpenCTI connector.

Since OpenCTI's data model IS STIX 2.1, this mapper is primarily
concerned with:

  A — OpenCTI GraphQL response → CTM-SAK STIX ORM dict
      Field name normalisation (GraphQL camelCase → STIX snake_case)
      Nested edge unwrapping (edges.node patterns)
      standard_id extraction for STIX IDs

  B — CTM-SAK STIX ORM dict → OpenCTI GraphQL input
      Building mutation input objects from STIX dicts
      Pattern generation from SCO types (for indicator creation)

  C — OpenCTI objects → STIX 2.1 bundle construction
      Wrapping lists of OpenCTI objects into standards-compliant bundles

  D — STIX bundle → individual OpenCTI create calls
      Parsing inbound STIX bundles and routing to the appropriate
      OpenCTI domain command (indicators, observables, threat actors)

Direction D is the most complex — it handles STIX bundle ingestion,
mapping each object type to the correct OpenCTI mutation and input
shape, and managing deduplication by standard_id.

STIX object type → OpenCTI entity type mapping
------------------------------------------------
  indicator          → Indicator (via indicatorAdd mutation)
  ipv4-addr          → IPv4-Addr observable
  ipv6-addr          → IPv6-Addr observable
  domain-name        → Domain-Name observable
  url                → Url observable
  file               → StixFile observable
  email-addr         → Email-Addr observable
  user-account       → User-Account observable
  threat-actor       → ThreatActor (via threatActorGroupAdd)
  malware            → Malware
  attack-pattern     → AttackPattern
  vulnerability      → Vulnerability
  report             → Report
  relationship       → StixCoreRelationship
  bundle             → (unwrapped, each object processed individually)

References
----------
- https://docs.opencti.io/latest/reference/api/
- https://oasis-open.github.io/cti-documentation/stix/intro.html
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from .exceptions import OpenCTISTIXError

if TYPE_CHECKING:
    from .indicators import OpenCTIIndicatorCommands
    from .observables import OpenCTIObservableCommands


_STIX_NS = uuid.UUID("00abedb4-aa42-466c-9c01-fed23315a9b7")

# Map STIX SCO type → OpenCTI observable type string
_SCO_TO_OPENCTI: dict[str, str] = {
    "ipv4-addr": "IPv4-Addr",
    "ipv6-addr": "IPv6-Addr",
    "domain-name": "Domain-Name",
    "url": "Url",
    "file": "StixFile",
    "email-addr": "Email-Addr",
    "user-account": "User-Account",
    "autonomous-system": "Autonomous-System",
    "windows-registry-key": "Windows-Registry-Key",
    "x509-certificate": "X509-Certificate",
    "network-traffic": "Network-Traffic",
}

_OPENCTI_TO_SCO: dict[str, str] = {v: k for k, v in _SCO_TO_OPENCTI.items()}


class OpenCTISTIXMapper:
    """
    STIX 2.1 ↔ OpenCTI field mapping utilities.

    Usage
    -----
    mapper = OpenCTISTIXMapper()

    # OpenCTI indicator node → STIX dict
    stix_obj = mapper.indicator_to_stix(opencti_indicator_node)

    # Build a bundle from multiple OpenCTI nodes
    bundle = mapper.to_stix_bundle([ind1, ind2, obs1])

    # Route STIX bundle objects to OpenCTI mutations
    results = mapper.ingest_bundle(bundle, indicators_cmd, observables_cmd)
    """

    # ── A: OpenCTI → STIX ─────────────────────────────────────────────────

    def indicator_to_stix(self, node: dict) -> dict:
        """
        Convert an OpenCTI indicator GraphQL node to a STIX 2.1 indicator SDO dict.

        Parameters
        ----------
        node : dict
            OpenCTI indicator node from GraphQL response.

        Returns
        -------
        dict
            STIX 2.1 indicator SDO.
        """
        now = _now_ts()
        kill_chain_phases = [
            {
                "kill_chain_name": kcp.get("kill_chain_name", ""),
                "phase_name": kcp.get("phase_name", ""),
            }
            for kcp in node.get("killChainPhases", [])
        ]
        ext_refs = [
            {
                "source_name": er.get("source_name", ""),
                "url": er.get("url", ""),
                "description": er.get("description", ""),
            }
            for er in [
                edge.get("node", {})
                for edge in node.get("externalReferences", {}).get("edges", [])
            ]
        ]

        obj: dict = {
            "type": "indicator",
            "id": node.get("standard_id") or f"indicator--{_det_uuid('indicator', node.get('id', ''))}",
            "spec_version": "2.1",
            "created": node.get("created") or now,
            "modified": node.get("modified") or now,
            "name": node.get("name", ""),
            "description": node.get("description", ""),
            "pattern": node.get("pattern", ""),
            "pattern_type": node.get("pattern_type", "stix"),
            "valid_from": node.get("valid_from") or now,
            "indicator_types": node.get("indicator_types") or ["malicious-activity"],
            "confidence": node.get("confidence", 0),
        }
        if node.get("valid_until"):
            obj["valid_until"] = node["valid_until"]
        if node.get("revoked"):
            obj["revoked"] = True
        if kill_chain_phases:
            obj["kill_chain_phases"] = kill_chain_phases
        if ext_refs:
            obj["external_references"] = ext_refs
        if node.get("x_opencti_score") is not None:
            obj["x_opencti_score"] = node["x_opencti_score"]
        if node.get("x_opencti_main_observable_type"):
            obj["x_opencti_main_observable_type"] = node["x_opencti_main_observable_type"]
        return obj

    def observable_to_stix(self, node: dict) -> dict | None:
        """
        Convert an OpenCTI observable node to a STIX 2.1 SCO dict.

        Parameters
        ----------
        node : dict
            OpenCTI observable GraphQL node.

        Returns
        -------
        dict | None
            STIX 2.1 SCO dict, or None if type is unsupported.
        """
        entity_type = node.get("entity_type", "")
        stix_type = _OPENCTI_TO_SCO.get(entity_type)
        if not stix_type:
            return None

        now = _now_ts()
        value = node.get("observable_value") or node.get("value", "")
        obj_id = (
            node.get("standard_id")
            or f"{stix_type}--{_det_uuid(stix_type, value)}"
        )

        base: dict = {
            "type": stix_type,
            "id": obj_id,
            "spec_version": "2.1",
        }

        if stix_type in ("ipv4-addr", "ipv6-addr", "domain-name", "url", "email-addr"):
            base["value"] = value

        elif stix_type == "file":
            if name := node.get("name"):
                base["name"] = name
            if size := node.get("size"):
                base["size"] = size
            hashes = {}
            for h in node.get("hashes", []):
                algo = h.get("algorithm", "")
                val = h.get("value", "")
                if algo and val:
                    hashes[algo] = val
            if hashes:
                base["hashes"] = hashes

        elif stix_type == "user-account":
            base["user_id"] = node.get("user_id") or value
            if login := node.get("account_login"):
                base["account_login"] = login
            if acct_type := node.get("account_type"):
                base["account_type"] = acct_type

        elif stix_type == "autonomous-system":
            base["number"] = node.get("number", 0)
            if name := node.get("name"):
                base["name"] = name

        return base

    def threat_actor_to_stix(self, node: dict) -> dict:
        """
        Convert an OpenCTI threat actor node to a STIX 2.1 threat-actor SDO.

        Parameters
        ----------
        node : dict
            OpenCTI threat actor GraphQL node.

        Returns
        -------
        dict
            STIX 2.1 threat-actor SDO.
        """
        now = _now_ts()
        return {
            "type": "threat-actor",
            "id": node.get("standard_id") or f"threat-actor--{_det_uuid('threat-actor', node.get('id', ''))}",
            "spec_version": "2.1",
            "created": node.get("created") or now,
            "modified": node.get("modified") or now,
            "name": node.get("name", ""),
            "description": node.get("description", ""),
            "threat_actor_types": node.get("threat_actor_types", ["unknown"]),
            "aliases": node.get("aliases", []),
            "goals": node.get("goals", []),
            "sophistication": node.get("sophistication"),
            "resource_level": node.get("resource_level"),
            "confidence": node.get("confidence", 0),
        }

    def relationship_to_stix(self, node: dict) -> dict:
        """
        Convert an OpenCTI relationship node to a STIX 2.1 relationship SRO.

        Parameters
        ----------
        node : dict
            OpenCTI relationship GraphQL node.

        Returns
        -------
        dict
            STIX 2.1 relationship SRO.
        """
        now = _now_ts()
        from_obj = node.get("from", {})
        to_obj = node.get("to", {})
        return {
            "type": "relationship",
            "id": node.get("standard_id") or f"relationship--{uuid.uuid4()}",
            "spec_version": "2.1",
            "created": node.get("created") or now,
            "modified": node.get("modified") or now,
            "relationship_type": node.get("relationship_type", "related-to"),
            "source_ref": from_obj.get("standard_id") or from_obj.get("id", ""),
            "target_ref": to_obj.get("standard_id") or to_obj.get("id", ""),
            "description": node.get("description", ""),
            "confidence": node.get("confidence", 0),
            "start_time": node.get("start_time"),
            "stop_time": node.get("stop_time"),
        }

    # ── B: CTM-SAK STIX → OpenCTI pattern ─────────────────────────────────

    @staticmethod
    def sco_to_stix_pattern(sco: dict) -> str | None:
        """
        Generate a STIX 2.1 pattern string from an SCO dict.

        Used when creating OpenCTI indicators from SCOs.

        Parameters
        ----------
        sco : dict
            STIX 2.1 SCO dict.

        Returns
        -------
        str | None
            STIX pattern string, or None if pattern cannot be generated.
        """
        sco_type = sco.get("type", "")
        if sco_type in ("ipv4-addr", "ipv6-addr"):
            value = sco.get("value")
            return f"[{sco_type}:value = '{value}']" if value else None
        if sco_type == "domain-name":
            return f"[domain-name:value = '{sco.get('value')}']" if sco.get("value") else None
        if sco_type == "url":
            return f"[url:value = '{sco.get('value')}']" if sco.get("value") else None
        if sco_type == "email-addr":
            return f"[email-addr:value = '{sco.get('value')}']" if sco.get("value") else None
        if sco_type == "file":
            hashes = sco.get("hashes", {})
            for algo in ("SHA-256", "SHA-1", "MD5"):
                if v := hashes.get(algo):
                    return f"[file:hashes.'{algo}' = '{v}']"
        return None

    # ── C: Bundle construction ─────────────────────────────────────────────

    def to_stix_bundle(self, nodes: list[dict]) -> dict:
        """
        Convert a list of OpenCTI object nodes to a STIX 2.1 bundle.

        Automatically detects node type from ``entity_type`` or ``type``
        and applies the correct conversion.

        Parameters
        ----------
        nodes : list[dict]
            Mixed list of OpenCTI GraphQL nodes (indicators, observables,
            threat actors, relationships, etc.)

        Returns
        -------
        dict
            STIX 2.1 bundle.
        """
        objects: list[dict] = []
        seen: set[str] = set()

        for node in nodes:
            entity_type = node.get("entity_type", "") or node.get("type", "")
            stix_obj: dict | None = None

            if entity_type == "Indicator" or node.get("pattern"):
                stix_obj = self.indicator_to_stix(node)
            elif entity_type in _OPENCTI_TO_SCO or entity_type in _SCO_TO_OPENCTI.values():
                stix_obj = self.observable_to_stix(node)
            elif "ThreatActor" in entity_type or entity_type == "threat-actor":
                stix_obj = self.threat_actor_to_stix(node)
            elif entity_type in ("StixCoreRelationship", "relationship") or node.get("relationship_type"):
                stix_obj = self.relationship_to_stix(node)

            if stix_obj and stix_obj.get("id") not in seen:
                seen.add(stix_obj["id"])
                objects.append(stix_obj)

        return {
            "type": "bundle",
            "id": f"bundle--{uuid.uuid4()}",
            "spec_version": "2.1",
            "objects": objects,
        }

    # ── D: STIX bundle ingestion ───────────────────────────────────────────

    def ingest_bundle(
        self,
        bundle: dict,
        indicators_cmd,
        observables_cmd,
        skip_existing: bool = True,
    ) -> dict:
        """
        Parse a STIX 2.1 bundle and create objects in OpenCTI.

        Routes each STIX object to the appropriate OpenCTI command:
          - indicator SDO → indicators_cmd.create()
          - ipv4/domain/url/file/email SCOs → observables_cmd.create_*()
          - Other types are logged and skipped

        Parameters
        ----------
        bundle : dict
            STIX 2.1 bundle dict.
        indicators_cmd : OpenCTIIndicatorCommands
            Indicator command instance.
        observables_cmd : OpenCTIObservableCommands
            Observable command instance.
        skip_existing : bool
            If True, silently skip objects that already exist (standard_id
            deduplication via get_by_pattern / get).

        Returns
        -------
        dict
            Summary with keys:
              created_indicators, created_observables,
              skipped, errors (list of {id, error} dicts)
        """
        if bundle.get("type") != "bundle":
            raise OpenCTISTIXError(
                f"Expected STIX bundle, got type='{bundle.get('type')}'."
            )

        summary = {
            "created_indicators": 0,
            "created_observables": 0,
            "skipped": 0,
            "errors": [],
        }

        for obj in bundle.get("objects", []):
            obj_type = obj.get("type", "")
            obj_id = obj.get("id", "unknown")
            try:
                if obj_type == "indicator":
                    self._ingest_indicator(obj, indicators_cmd, skip_existing)
                    summary["created_indicators"] += 1
                elif obj_type in _SCO_TO_OPENCTI:
                    self._ingest_observable(obj, observables_cmd)
                    summary["created_observables"] += 1
                elif obj_type in ("relationship", "bundle", "identity",
                                   "marking-definition", "extension-definition"):
                    summary["skipped"] += 1
                else:
                    summary["skipped"] += 1
            except Exception as exc:
                summary["errors"].append({"id": obj_id, "error": str(exc)})

        return summary

    # ── Internal ───────────────────────────────────────────────────────────

    @staticmethod
    def _ingest_indicator(obj: dict, indicators_cmd, skip_existing: bool) -> None:
        """Route a STIX indicator SDO to indicators_cmd.create()."""
        if skip_existing:
            existing = indicators_cmd.get_by_pattern(obj.get("pattern", ""))
            if existing:
                return

        name = obj.get("name") or obj.get("id", "Unnamed Indicator")
        pattern = obj.get("pattern", "")
        if not pattern:
            raise OpenCTISTIXError(f"Indicator {obj.get('id')} has no pattern.")

        indicators_cmd.create(
            name=name,
            pattern=pattern,
            pattern_type=obj.get("pattern_type", "stix"),
            valid_from=obj.get("valid_from"),
            valid_until=obj.get("valid_until"),
            description=obj.get("description", ""),
            confidence=obj.get("confidence", 75),
            score=obj.get("x_opencti_score", 50),
            indicator_types=obj.get("indicator_types", ["malicious-activity"]),
            main_observable_type=obj.get("x_opencti_main_observable_type"),
        )

    @staticmethod
    def _ingest_observable(obj: dict, observables_cmd) -> None:
        """Route a STIX SCO to the appropriate observables_cmd.create_*() method."""
        obj_type = obj.get("type", "")
        if obj_type in ("ipv4-addr", "ipv6-addr"):
            if obj_type == "ipv4-addr":
                observables_cmd.create_ipv4(obj.get("value", ""))
            else:
                observables_cmd.create_ipv6(obj.get("value", ""))
        elif obj_type == "domain-name":
            observables_cmd.create_domain(obj.get("value", ""))
        elif obj_type == "url":
            observables_cmd.create_url(obj.get("value", ""))
        elif obj_type == "email-addr":
            observables_cmd.create_email(obj.get("value", ""))
        elif obj_type == "file":
            hashes = obj.get("hashes", {})
            observables_cmd.create_file(
                name=obj.get("name"),
                md5=hashes.get("MD5"),
                sha1=hashes.get("SHA-1"),
                sha256=hashes.get("SHA-256"),
                size=obj.get("size"),
            )
        elif obj_type == "user-account":
            observables_cmd.create_user_account(
                user_id=obj.get("user_id", obj.get("account_login", "")),
                account_login=obj.get("account_login"),
                account_type=obj.get("account_type"),
            )


# ── Utility functions ──────────────────────────────────────────────────────────

def _det_uuid(stix_type: str, value: str) -> str:
    return str(uuid.uuid5(_STIX_NS, f"{stix_type}:{value}"))


def _now_ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
