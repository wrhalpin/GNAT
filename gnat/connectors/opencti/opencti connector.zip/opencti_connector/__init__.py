"""
CTM-SAK OpenCTI Connector
==========================
Connector for the OpenCTI Open Cyber Threat Intelligence Platform.

API surface
-----------
OpenCTI exposes three integration interfaces:

  1. GraphQL API  (/graphql)
     ─────────────────────────────────────────────────────────────
     Primary programmatic interface. All CRUD operations on CTI
     objects (indicators, observables, threat actors, reports, etc.)
     are performed via GraphQL queries and mutations.

     Every request is a POST to /graphql with a JSON body:
       {"query": "<GraphQL operation>", "variables": {...}}

     CTM-SAK implements a lightweight GraphQL-over-urllib3 client
     rather than using pycti, to remain consistent with the project's
     urllib3-only HTTP foundation.

  2. TAXII 2.1 Server  (/taxii2/)
     ─────────────────────────────────────────────────────────────
     OpenCTI acts as a TAXII 2.1 server, serving STIX 2.1 bundles
     from configurable collections. CTM-SAK can consume these feeds
     via OpenCTITAXIICommands, which uses standard TAXII discovery
     and collection poll endpoints.

  3. SSE Live Stream  (/stream)
     ─────────────────────────────────────────────────────────────
     Server-Sent Events endpoint delivering a real-time pure STIX 2.1
     stream of platform changes. Supports filtering and cursor-based
     resumption. OpenCTIStreamCommands provides a generator interface
     for stream consumption.

Auth
----
All three surfaces use the same Bearer token:
  Authorization: Bearer <api_key>

The API key is found in OpenCTI under:
  User menu → Profile → API Access → Your API key

STIX 2.1 support
----------------
Native. OpenCTI's data model is built directly on STIX 2.1 standards.
Every object carries a ``standard_id`` (STIX 2.1 ID), and the platform
supports STIX pattern syntax for indicators natively.

The OpenCTISTIXMapper converts between OpenCTI GraphQL response shapes
and CTM-SAK ORM STIX 2.1 dicts. Since OpenCTI IS STIX, this mapper is
primarily concerned with field name normalisation rather than semantic
translation.

Dev access
----------
Free, open source, self-hosted.
  Docker Compose:
    https://docs.opencti.io/latest/deployment/installation/
  Live demo instance (resets nightly):
    https://demo.opencti.io/

Configuration section (ctm_sak.ini):
  [opencti]
  url               = https://opencti.corp.example.com
  api_key           =
  verify_ssl        = true
  timeout           = 30
  max_results       = 100
  taxii_enabled     = false
  stream_enabled    = false
  stream_id         = live            ; stream ID or 'live' for main stream
"""

from .client import OpenCTIClient
from .auth import OpenCTIAuthManager
from .graphql_client import OpenCTIGraphQLClient
from .indicators import OpenCTIIndicatorCommands
from .observables import OpenCTIObservableCommands
from .threat_actors import OpenCTIThreatActorCommands
from .relationships import OpenCTIRelationshipCommands
from .reports import OpenCTIReportCommands
from .taxii import OpenCTITAXIICommands
from .stream import OpenCTIStreamCommands
from .stix_mapper import OpenCTISTIXMapper
from .config import OpenCTIConfig, load_opencti_config
from .exceptions import (
    OpenCTIAuthError,
    OpenCTIGraphQLError,
    OpenCTINotFoundError,
    OpenCTIConfigError,
    OpenCTISTIXError,
    OpenCTITAXIIError,
    OpenCTIStreamError,
)

__all__ = [
    "OpenCTIClient",
    "OpenCTIAuthManager",
    "OpenCTIGraphQLClient",
    "OpenCTIIndicatorCommands",
    "OpenCTIObservableCommands",
    "OpenCTIThreatActorCommands",
    "OpenCTIRelationshipCommands",
    "OpenCTIReportCommands",
    "OpenCTITAXIICommands",
    "OpenCTIStreamCommands",
    "OpenCTISTIXMapper",
    "OpenCTIConfig",
    "load_opencti_config",
    "OpenCTIAuthError",
    "OpenCTIGraphQLError",
    "OpenCTINotFoundError",
    "OpenCTIConfigError",
    "OpenCTISTIXError",
    "OpenCTITAXIIError",
    "OpenCTIStreamError",
]

__version__ = "0.1.0"
__platform__ = "OpenCTI Open Cyber Threat Intelligence Platform"
__api_versions__ = ["5.x", "6.x"]
__stix_support__ = "native"  # OpenCTI data model IS STIX 2.1
