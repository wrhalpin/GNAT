"""
ctm_sak.connectors.opencti.threat_actors
==========================================
Threat actor, malware, and attack pattern SDO commands.
"""

from typing import Iterator
from .graphql_client import OpenCTIGraphQLClient
from .config import OpenCTIConfig
from .exceptions import OpenCTINotFoundError


_ACTOR_FIELDS = """
  id standard_id name description
  threat_actor_types sophistication resource_level
  primary_motivation secondary_motivations goals
  aliases confidence
  created modified
  createdBy { id name }
  labels { edges { node { value color } } }
  externalReferences { edges { node { source_name url } } }
"""

_LIST_THREAT_ACTORS = """
query ListThreatActors($first: Int, $after: String, $filters: FilterGroup) {
  threatActors(first: $first, after: $after, filters: $filters) {
    pageInfo { hasNextPage endCursor }
    edges { node { """ + _ACTOR_FIELDS + """ } }
  }
}
"""

_GET_THREAT_ACTOR = """
query GetThreatActor($id: String!) {
  threatActor(id: $id) { """ + _ACTOR_FIELDS + """ }
}
"""

_CREATE_THREAT_ACTOR = """
mutation CreateThreatActor($input: ThreatActorGroupAddInput!) {
  threatActorGroupAdd(input: $input) { """ + _ACTOR_FIELDS + """ }
}
"""

_MALWARE_FIELDS = """
  id standard_id name description
  malware_types is_family
  aliases implementation_languages architecture_execution_envs
  capabilities confidence
  created modified
  labels { edges { node { value } } }
"""

_LIST_MALWARE = """
query ListMalware($first: Int, $after: String, $filters: FilterGroup) {
  malwares(first: $first, after: $after, filters: $filters) {
    pageInfo { hasNextPage endCursor }
    edges { node { """ + _MALWARE_FIELDS + """ } }
  }
}
"""

_ATTACK_PATTERN_FIELDS = """
  id standard_id name description
  x_mitre_id x_mitre_detection x_mitre_platforms
  aliases confidence created modified
  killChainPhases { kill_chain_name phase_name }
"""

_LIST_ATTACK_PATTERNS = """
query ListAttackPatterns($first: Int, $after: String, $filters: FilterGroup) {
  attackPatterns(first: $first, after: $after, filters: $filters) {
    pageInfo { hasNextPage endCursor }
    edges { node { """ + _ATTACK_PATTERN_FIELDS + """ } }
  }
}
"""


class OpenCTIThreatActorCommands:
    """
    Threat actor, malware, and attack pattern SDO operations.

    Parameters
    ----------
    gql : OpenCTIGraphQLClient
    config : OpenCTIConfig
    """

    def __init__(self, gql: OpenCTIGraphQLClient, config: OpenCTIConfig) -> None:
        self._gql = gql
        self._config = config

    # ── Threat Actors ──────────────────────────────────────────────────────

    def list_threat_actors(
        self, first: int | None = None, filters: dict | None = None
    ) -> list[dict]:
        """List threat actor SDOs."""
        vars: dict = {"first": first or self._config.max_results}
        if filters:
            vars["filters"] = filters
        data = self._gql.execute(_LIST_THREAT_ACTORS, variables=vars)
        return [e["node"] for e in data.get("threatActors", {}).get("edges", [])]

    def iter_threat_actors(self) -> Iterator[dict]:
        """Generator yielding all threat actors."""
        yield from self._gql.paginate("threatActors", _LIST_THREAT_ACTORS)

    def get_threat_actor(self, actor_id: str) -> dict:
        """Retrieve a single threat actor by ID."""
        data = self._gql.execute(_GET_THREAT_ACTOR, variables={"id": actor_id})
        obj = data.get("threatActor")
        if not obj:
            raise OpenCTINotFoundError(
                f"Threat actor '{actor_id}' not found.",
                errors=[], operation="GetThreatActor",
            )
        return obj

    def create_threat_actor(
        self,
        name: str,
        description: str = "",
        threat_actor_types: list[str] | None = None,
        aliases: list[str] | None = None,
        goals: list[str] | None = None,
        sophistication: str | None = None,
        resource_level: str | None = None,
        confidence: int = 75,
        labels: list[str] | None = None,
    ) -> dict:
        """Create a new threat actor SDO."""
        input_obj: dict = {
            "name": name,
            "description": description,
            "confidence": confidence,
            "threat_actor_types": threat_actor_types or ["unknown"],
        }
        if aliases:
            input_obj["aliases"] = aliases
        if goals:
            input_obj["goals"] = goals
        if sophistication:
            input_obj["sophistication"] = sophistication
        if resource_level:
            input_obj["resource_level"] = resource_level
        if labels:
            input_obj["objectLabel"] = labels

        return self._gql.mutate(
            _CREATE_THREAT_ACTOR,
            variables={"input": input_obj},
            result_field="threatActorGroupAdd",
        )

    # ── Malware ────────────────────────────────────────────────────────────

    def list_malware(
        self, first: int | None = None, filters: dict | None = None
    ) -> list[dict]:
        """List malware SDOs."""
        vars: dict = {"first": first or self._config.max_results}
        if filters:
            vars["filters"] = filters
        data = self._gql.execute(_LIST_MALWARE, variables=vars)
        return [e["node"] for e in data.get("malwares", {}).get("edges", [])]

    def iter_malware(self) -> Iterator[dict]:
        """Generator yielding all malware SDOs."""
        yield from self._gql.paginate("malwares", _LIST_MALWARE)

    # ── Attack Patterns (MITRE ATT&CK) ────────────────────────────────────

    def list_attack_patterns(
        self,
        first: int | None = None,
        filters: dict | None = None,
        mitre_id: str | None = None,
    ) -> list[dict]:
        """
        List attack pattern SDOs (MITRE ATT&CK techniques).

        Parameters
        ----------
        mitre_id : str | None
            Filter by MITRE ATT&CK ID (e.g. 'T1059').
        """
        vars: dict = {"first": first or self._config.max_results}
        if filters:
            vars["filters"] = filters
        elif mitre_id:
            vars["filters"] = {
                "mode": "and",
                "filters": [{"key": "x_mitre_id", "values": [mitre_id]}],
                "filterGroups": [],
            }
        data = self._gql.execute(_LIST_ATTACK_PATTERNS, variables=vars)
        return [e["node"] for e in data.get("attackPatterns", {}).get("edges", [])]

    def iter_attack_patterns(self) -> Iterator[dict]:
        """Generator yielding all attack pattern SDOs."""
        yield from self._gql.paginate("attackPatterns", _LIST_ATTACK_PATTERNS)

    # ── Normalisation ──────────────────────────────────────────────────────

    @staticmethod
    def normalise_threat_actor(actor: dict) -> dict:
        """Flatten OpenCTI threat actor node to CTM-SAK format."""
        labels = [
            e.get("node", {}).get("value", "")
            for e in actor.get("labels", {}).get("edges", [])
        ]
        return {
            "id": actor.get("id"),
            "standard_id": actor.get("standard_id"),
            "name": actor.get("name"),
            "description": actor.get("description"),
            "threat_actor_types": actor.get("threat_actor_types", []),
            "aliases": actor.get("aliases", []),
            "sophistication": actor.get("sophistication"),
            "resource_level": actor.get("resource_level"),
            "goals": actor.get("goals", []),
            "confidence": actor.get("confidence"),
            "labels": labels,
            "_raw": actor,
        }
