"""
ctm_sak.connectors.opencti.config
====================================
Configuration schema for the OpenCTI connector.

INI example
-----------
[opencti]
url               = https://opencti.corp.example.com
api_key           = xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
verify_ssl        = true
timeout           = 30
max_results       = 100
taxii_enabled     = false
stream_enabled    = false
stream_id         = live

Notes
-----
- ``url`` should be the base URL of the OpenCTI instance with no trailing slash.
  E.g.: https://demo.opencti.io  or  http://localhost:4000
- ``api_key`` is the UUID found under Profile → API Access in the OpenCTI UI.
- ``max_results`` is the default ``first`` argument for GraphQL list queries.
  OpenCTI does not hard-cap this, but very large values (>500) can be slow.
  Use the paginate helpers for full dataset iteration.
- ``taxii_enabled`` gates access to TAXII 2.1 collection endpoints.
  The TAXII server uses the same API key / Bearer auth.
- ``stream_enabled`` gates access to the SSE live stream.
  The stream also uses Bearer auth against /stream/<stream_id>.
- ``stream_id`` is the stream identifier. 'live' is the default main stream.
  Named streams can be created in OpenCTI's Data → Data Sharing → Live Streams.
"""

import configparser
from dataclasses import dataclass, field

from .exceptions import OpenCTIConfigError


_REQUIRED = {"url", "api_key"}

_DEFAULTS: dict = {
    "url": "",
    "api_key": "",
    "verify_ssl": "true",
    "timeout": "30",
    "max_results": "100",
    "taxii_enabled": "false",
    "stream_enabled": "false",
    "stream_id": "live",
}


@dataclass
class OpenCTIConfig:
    """
    Validated configuration for the OpenCTI connector.

    Attributes
    ----------
    url : str
        Base URL of the OpenCTI instance (no trailing slash).
    api_key : str
        OpenCTI API key (UUID format).
    verify_ssl : bool
        Whether to verify TLS certificates.
    timeout : int
        HTTP timeout in seconds.
    max_results : int
        Default ``first`` argument for GraphQL list queries.
    taxii_enabled : bool
        Enable TAXII 2.1 collection endpoints.
    stream_enabled : bool
        Enable SSE live stream consumption.
    stream_id : str
        Stream identifier for SSE. 'live' = main OpenCTI stream.
    graphql_url : str
        Computed GraphQL endpoint URL.
    taxii_url : str
        Computed TAXII 2.1 root URL.
    stream_url : str
        Computed SSE stream URL.
    """

    url: str
    api_key: str
    verify_ssl: bool = True
    timeout: int = 30
    max_results: int = 100
    taxii_enabled: bool = False
    stream_enabled: bool = False
    stream_id: str = "live"
    graphql_url: str = field(init=False)
    taxii_url: str = field(init=False)
    stream_url: str = field(init=False)

    def __post_init__(self) -> None:
        # Normalise URL — strip trailing slash
        self.url = self.url.rstrip("/")
        self.graphql_url = f"{self.url}/graphql"
        self.taxii_url = f"{self.url}/taxii2"
        self.stream_url = f"{self.url}/stream/{self.stream_id}"
        self._validate()

    def _validate(self) -> None:
        if not self.url:
            raise OpenCTIConfigError("'url' is required in [opencti] config.")
        if not self.api_key:
            raise OpenCTIConfigError("'api_key' is required in [opencti] config.")
        if not self.url.startswith(("http://", "https://")):
            raise OpenCTIConfigError(
                f"'url' must start with http:// or https://. Got: {self.url!r}"
            )
        if self.timeout <= 0:
            raise OpenCTIConfigError("'timeout' must be a positive integer.")
        if self.max_results <= 0:
            raise OpenCTIConfigError("'max_results' must be a positive integer.")

    @property
    def auth_headers(self) -> dict[str, str]:
        """Return the Authorization header for all API surfaces."""
        return {"Authorization": f"Bearer {self.api_key}"}

    @property
    def graphql_headers(self) -> dict[str, str]:
        """Return headers for GraphQL POST requests."""
        return {
            **self.auth_headers,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    @property
    def taxii_headers(self) -> dict[str, str]:
        """
        Return headers for TAXII 2.1 requests.

        TAXII 2.1 uses application/taxii+json;version=2.1 as Accept type.
        OpenCTI also accepts application/json.
        """
        return {
            **self.auth_headers,
            "Accept": "application/taxii+json;version=2.1",
        }

    @property
    def stream_headers(self) -> dict[str, str]:
        """Return headers for SSE stream requests."""
        return {
            **self.auth_headers,
            "Accept": "text/event-stream",
        }


def load_opencti_config(
    config: configparser.ConfigParser,
    section: str = "opencti",
) -> OpenCTIConfig:
    """
    Parse [opencti] section from a ctm_sak.ini ConfigParser instance.

    Parameters
    ----------
    config : configparser.ConfigParser
        Already-loaded ConfigParser.
    section : str
        INI section name. Defaults to 'opencti'.

    Returns
    -------
    OpenCTIConfig

    Raises
    ------
    OpenCTIConfigError
    """
    if not config.has_section(section):
        raise OpenCTIConfigError(
            f"Configuration section '[{section}]' not found in ctm_sak.ini."
        )

    raw = dict(_DEFAULTS)
    raw.update(dict(config.items(section)))

    missing = {k for k in _REQUIRED if not raw.get(k, "").strip()}
    if missing:
        raise OpenCTIConfigError(
            f"Missing required [opencti] config keys: {', '.join(sorted(missing))}"
        )

    def _bool(v: str) -> bool:
        return v.strip().lower() in ("true", "1", "yes")

    return OpenCTIConfig(
        url=raw["url"].strip(),
        api_key=raw["api_key"].strip(),
        verify_ssl=_bool(raw["verify_ssl"]),
        timeout=int(raw["timeout"]),
        max_results=int(raw["max_results"]),
        taxii_enabled=_bool(raw["taxii_enabled"]),
        stream_enabled=_bool(raw["stream_enabled"]),
        stream_id=raw["stream_id"].strip(),
    )
