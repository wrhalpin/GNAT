"""
ctm_sak.connectors.opencti.taxii
===================================
TAXII 2.1 client commands for OpenCTI's built-in TAXII server.

OpenCTI implements a TAXII 2.1 server at /taxii2/.
Collections map to OpenCTI data streams filtered by type or label.

TAXII 2.1 endpoints
--------------------
  GET  /taxii2/                          — discovery
  GET  /taxii2/<api-root>/               — API root info
  GET  /taxii2/<api-root>/collections/   — list collections
  GET  /taxii2/<api-root>/collections/<id>/  — collection info
  GET  /taxii2/<api-root>/collections/<id>/objects/  — get objects (STIX bundle)

Default API root in OpenCTI is: ``root``
Full path: /taxii2/root/collections/

Authentication: Bearer <api_key> (same as GraphQL)

Response Content-Type: application/taxii+json;version=2.1

References
----------
- https://docs.opencti.io/latest/deployment/integrations/
- https://www.oasis-open.org/standard/taxii/
"""

import json
import urllib.parse
import urllib3

from .config import OpenCTIConfig
from .exceptions import OpenCTIAuthError, OpenCTITAXIIError


_DEFAULT_API_ROOT = "root"


class OpenCTITAXIICommands:
    """
    OpenCTI TAXII 2.1 server client.

    Only available when ``taxii_enabled = true`` in [opencti] config.

    Parameters
    ----------
    config : OpenCTIConfig
    http : urllib3.PoolManager
    """

    def __init__(self, config: OpenCTIConfig, http: urllib3.PoolManager) -> None:
        self._config = config
        self._http = http
        self._api_root = _DEFAULT_API_ROOT

    # ── Discovery ──────────────────────────────────────────────────────────

    def discover(self) -> dict:
        """
        Retrieve the TAXII 2.1 discovery document.

        Returns
        -------
        dict
            TAXII server discovery info including api_roots.
        """
        return self._get(self._config.taxii_url)

    def get_api_root(self, api_root: str | None = None) -> dict:
        """
        Get information about a specific TAXII API root.

        Parameters
        ----------
        api_root : str | None
            API root name. Defaults to 'root'.

        Returns
        -------
        dict
            API root metadata.
        """
        root = api_root or self._api_root
        url = f"{self._config.taxii_url}/{root}/"
        return self._get(url)

    # ── Collections ────────────────────────────────────────────────────────

    def list_collections(self, api_root: str | None = None) -> list[dict]:
        """
        List all TAXII collections in an API root.

        Parameters
        ----------
        api_root : str | None
            API root name. Defaults to 'root'.

        Returns
        -------
        list[dict]
            Collection metadata dicts with id, title, can_read, can_write,
            description, media_types.
        """
        root = api_root or self._api_root
        url = f"{self._config.taxii_url}/{root}/collections/"
        response = self._get(url)
        return response.get("collections", [])

    def get_collection(
        self,
        collection_id: str,
        api_root: str | None = None,
    ) -> dict:
        """
        Get metadata for a specific TAXII collection.

        Parameters
        ----------
        collection_id : str
            TAXII collection UUID.
        api_root : str | None
            API root name.

        Returns
        -------
        dict
            Collection metadata.
        """
        root = api_root or self._api_root
        url = f"{self._config.taxii_url}/{root}/collections/{collection_id}/"
        return self._get(url)

    # ── Objects (STIX bundles) ─────────────────────────────────────────────

    def get_objects(
        self,
        collection_id: str,
        api_root: str | None = None,
        added_after: str | None = None,
        limit: int = 100,
        next_cursor: str | None = None,
        match_type: list[str] | None = None,
    ) -> dict:
        """
        Retrieve STIX 2.1 objects from a TAXII collection.

        Parameters
        ----------
        collection_id : str
            TAXII collection UUID.
        api_root : str | None
            API root. Defaults to 'root'.
        added_after : str | None
            ISO 8601 timestamp — only objects added after this time.
        limit : int
            Max objects per request.
        next_cursor : str | None
            Pagination cursor from a previous response's ``next`` field.
        match_type : list[str] | None
            Filter by STIX object type(s), e.g. ['indicator', 'malware'].

        Returns
        -------
        dict
            TAXII envelope with ``objects`` (STIX bundle items), ``more``,
            and ``next`` cursor.
        """
        root = api_root or self._api_root
        url = f"{self._config.taxii_url}/{root}/collections/{collection_id}/objects/"
        params: dict = {"limit": limit}
        if added_after:
            params["added_after"] = added_after
        if next_cursor:
            params["next"] = next_cursor
        if match_type:
            params["match[type]"] = ",".join(match_type)
        if params:
            url += f"?{urllib.parse.urlencode(params)}"
        return self._get(url)

    def iter_collection_objects(
        self,
        collection_id: str,
        api_root: str | None = None,
        added_after: str | None = None,
        match_type: list[str] | None = None,
        page_size: int = 100,
    ):
        """
        Generator that yields all STIX objects from a TAXII collection.

        Handles TAXII 2.1 pagination via the ``next`` cursor.

        Parameters
        ----------
        collection_id : str
            TAXII collection UUID.
        api_root : str | None
            API root.
        added_after : str | None
            Only objects added after this timestamp.
        match_type : list[str] | None
            STIX type filter.
        page_size : int
            Objects per request.

        Yields
        ------
        dict
            Individual STIX object dicts.
        """
        cursor: str | None = None

        while True:
            response = self.get_objects(
                collection_id,
                api_root=api_root,
                added_after=added_after,
                limit=page_size,
                next_cursor=cursor,
                match_type=match_type,
            )
            objects = response.get("objects", [])
            yield from objects

            if not response.get("more"):
                break
            cursor = response.get("next")
            if not cursor:
                break

    def get_collection_as_bundle(
        self,
        collection_id: str,
        api_root: str | None = None,
        added_after: str | None = None,
    ) -> dict:
        """
        Download an entire TAXII collection as a single STIX 2.1 bundle.

        For large collections prefer iter_collection_objects().

        Parameters
        ----------
        collection_id : str
            TAXII collection UUID.
        api_root : str | None
            API root.
        added_after : str | None
            Time filter.

        Returns
        -------
        dict
            STIX 2.1 bundle dict.
        """
        import uuid as _uuid
        objects = list(self.iter_collection_objects(
            collection_id, api_root=api_root, added_after=added_after
        ))
        return {
            "type": "bundle",
            "id": f"bundle--{_uuid.uuid4()}",
            "spec_version": "2.1",
            "objects": objects,
        }

    # ── Internal ───────────────────────────────────────────────────────────

    def _get(self, url: str) -> dict:
        """Execute a TAXII GET request."""
        try:
            response = self._http.request(
                "GET",
                url,
                headers=self._config.taxii_headers,
                timeout=self._config.timeout,
            )
        except urllib3.exceptions.HTTPError as exc:
            raise OpenCTITAXIIError(f"TAXII request failed: {exc}") from exc

        if response.status == 401:
            raise OpenCTIAuthError(
                "TAXII authentication failed (HTTP 401). Check api_key."
            )
        if response.status == 404:
            raise OpenCTITAXIIError(
                f"TAXII resource not found: {url}", status_code=404
            )
        if response.status != 200:
            raise OpenCTITAXIIError(
                f"TAXII request returned HTTP {response.status}.",
                status_code=response.status,
            )

        try:
            return json.loads(response.data.decode("utf-8"))
        except Exception as exc:
            raise OpenCTITAXIIError(
                f"Failed to parse TAXII response: {exc}"
            ) from exc
