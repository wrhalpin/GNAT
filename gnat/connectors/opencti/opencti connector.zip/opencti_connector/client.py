"""
ctm_sak.connectors.opencti.client
====================================
Top-level client for the OpenCTI connector.

Assembles all components — GraphQL engine, auth manager, and domain
command classes — into a single entry point with context manager support.

Usage
-----
    cfg = load_opencti_config(parser)
    with OpenCTIClient(cfg) as client:
        # GraphQL operations
        indicators = client.indicators.list()
        observable = client.observables.create_ipv4("1.2.3.4")

        # TAXII 2.1 (if taxii_enabled)
        collections = client.taxii.list_collections()

        # SSE stream (if stream_enabled)
        for event in client.stream.iter_events():
            process(event)
"""

import urllib3

from .auth import OpenCTIAuthManager
from .config import OpenCTIConfig
from .graphql_client import OpenCTIGraphQLClient
from .indicators import OpenCTIIndicatorCommands
from .observables import OpenCTIObservableCommands
from .threat_actors import OpenCTIThreatActorCommands
from .relationships import OpenCTIRelationshipCommands
from .reports import OpenCTIReportCommands
from .taxii import OpenCTITAXIICommands
from .stream import OpenCTIStreamCommands
from .exceptions import OpenCTITAXIIError, OpenCTIStreamError


class OpenCTIClient:
    """
    Top-level OpenCTI connector client.

    All domain operations are accessible as attributes:
      client.indicators    — OpenCTIIndicatorCommands
      client.observables   — OpenCTIObservableCommands
      client.threat_actors — OpenCTIThreatActorCommands
      client.relationships — OpenCTIRelationshipCommands
      client.reports       — OpenCTIReportCommands
      client.taxii         — OpenCTITAXIICommands (if taxii_enabled)
      client.stream        — OpenCTIStreamCommands (if stream_enabled)
      client.gql           — OpenCTIGraphQLClient (direct GraphQL access)

    Parameters
    ----------
    config : OpenCTIConfig
        Validated connector configuration.
    """

    def __init__(self, config: OpenCTIConfig) -> None:
        self.config = config
        self._http = self._build_pool_manager()

        # Core components
        self.auth = OpenCTIAuthManager(config, self._http)
        self.gql = OpenCTIGraphQLClient(config, self._http)

        # Domain commands
        self.indicators = OpenCTIIndicatorCommands(self.gql, config)
        self.observables = OpenCTIObservableCommands(self.gql, config)
        self.threat_actors = OpenCTIThreatActorCommands(self.gql, config)
        self.relationships = OpenCTIRelationshipCommands(self.gql, config)
        self.reports = OpenCTIReportCommands(self.gql, config)

        # Optional surfaces
        if config.taxii_enabled:
            self.taxii = OpenCTITAXIICommands(config, self._http)
        else:
            self.taxii = _DisabledSurface("taxii", "taxii_enabled")

        if config.stream_enabled:
            self.stream = OpenCTIStreamCommands(config, self._http)
        else:
            self.stream = _DisabledSurface("stream", "stream_enabled")

    # ── Context manager ───────────────────────────────────────────────────

    def __enter__(self) -> "OpenCTIClient":
        return self

    def __exit__(self, *_) -> None:
        self.close()

    def close(self) -> None:
        """Release urllib3 connection pool resources."""
        self._http.clear()

    # ── Convenience methods ────────────────────────────────────────────────

    def verify(self) -> dict:
        """
        Verify connectivity and API key validity.

        Returns
        -------
        dict
            Authenticated user info (id, name, capabilities).
        """
        return self.auth.verify()

    def ping(self) -> bool:
        """
        Simple connectivity check.

        Returns
        -------
        bool
            True if the OpenCTI instance is reachable and the key is valid.
        """
        try:
            self.auth.verify()
            return True
        except Exception:
            return False

    def execute(self, query: str, variables: dict | None = None) -> dict:
        """
        Execute a raw GraphQL query or mutation directly.

        For advanced use cases not covered by the domain command classes.

        Parameters
        ----------
        query : str
            GraphQL operation string.
        variables : dict | None
            Variables dict.

        Returns
        -------
        dict
            GraphQL response data dict.
        """
        return self.gql.execute(query, variables=variables)

    # ── Internal ───────────────────────────────────────────────────────────

    def _build_pool_manager(self) -> urllib3.PoolManager:
        kwargs: dict = {
            "num_pools": 4,
            "maxsize": 10,
            "timeout": urllib3.Timeout(
                connect=10.0,
                read=float(self.config.timeout),
            ),
            "retries": urllib3.Retry(total=0, raise_on_status=False),
        }
        if not self.config.verify_ssl:
            kwargs["cert_reqs"] = "CERT_NONE"
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        else:
            kwargs["cert_reqs"] = "CERT_REQUIRED"
        return urllib3.PoolManager(**kwargs)


class _DisabledSurface:
    """
    Placeholder that raises a helpful error when a disabled
    surface (TAXII or Stream) is accessed.
    """

    def __init__(self, name: str, config_key: str) -> None:
        self._name = name
        self._config_key = config_key

    def __getattr__(self, item: str):
        raise RuntimeError(
            f"OpenCTI {self._name} surface is disabled. "
            f"Set '{self._config_key} = true' in [opencti] config to enable it."
        )
